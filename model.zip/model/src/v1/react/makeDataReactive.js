let $MB;

function _addProxy(data) {
	// debugger;
	const $tools = $MB.get('tools');
	const $bb = $MB.get('bb');

	if (typeof(data) == 'object') {
		if (!(Array.isArray(data) || $bb.$isPlainObject(data))) {
			// 物件只能是兩種格式
			throw new Error('...');
		}
		if ($tools.hasObserve(data)) {
			let ob = $tools.getObserve(data);
			return ob;
		}
	} else {
		// 簡單數值
		throw new Error('...');
	}
	//------------
	const ObserveNode = $MB.get('ObserveNode');
	let ob = new ObserveNode(data);
	return ob;
}
//-------------------------------------------
function _walkArray(data, p_ob) {
	// debugger;

	for (let i = 0; i < data.length; i++) {
		// debugger;
		// data[i] = data[i];
		
		let value = data[i];
		let {
			proxy,
		} = makeProxy(value, p_ob);
		data[i] = (proxy != null) ? proxy : value;		
	}
}
//-------------------------------------------
function _walkPlainObject(data, p_ob) {
	// debugger;
	for (let key in data) {
		// debugger;
		// data[key] = data[key];
		
		let value = data[key];
		let {
			proxy,
		} = makeProxy(value, p_ob);
		data[key] = (proxy != null) ? proxy : value;		
	}
}
//-------------------------------------------
// API
function makeProxy(data, parent = null) {
	// debugger;

	const $bb = $MB.get('bb');
	const $tools = $MB.get('tools');
	const ObserveNode = $MB.get('ObserveNode');
	let ob;

	if (data == null || typeof(data) != 'object') {
		return {
			value: data,
			ob,
		};
	}
	//-------------
	if ($tools.hasObserve(data)) {
		ob = $tools.getObserve(data);

		if (parent != null) {
			ob.setParent(parent);
		}
		return {
			value: ob.$raw,
			ob,
			proxy: ob.$proxy,
		};
	}
	//-------------
	// 加入追蹤功能
	ob = _addProxy(data);
	// debugger;
	if (parent != null) {
		ob.setParent(parent);
	}
	//-------------
	// debugger;
	const rawData = ob.$raw;
	let proxy = ob.$proxy;

	if (Array.isArray(rawData)) {
		_walkArray(rawData, ob);
	} else if ($bb.$isPlainObject(rawData)) {
		_walkPlainObject(rawData, ob);
	}
	//-------------
	// debugger;
	return {
		value: ob.raw,
		ob,
		proxy
	};
}
//-------------------------------------------
export function handle(mb) {
	$MB = mb;
	return makeProxy;
};
