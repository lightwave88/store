import MB from '../mb.js';
const $MB = new MB();
//-------------
import {
	handle as h_makeDataReactive
} from './makeDataReactive.js';
$MB.importHandle('makeDataReactive', h_makeDataReactive);
//-------------
import {
	handle as h_ob
} from './observe.js';
$MB.importHandle('ObserveNode', h_ob);
//-------------
import {
	handle as h_arrayProto
} from './arrayMethod.js';
$MB.importHandle('getArrayProto', h_arrayProto);
//-------------
import {
	handle as h_arrayProxy
} from './arrayProxySetting.js';
$MB.importHandle('arrayProxySetting', h_arrayProxy);
//-------------
import {
	handle as h_objProxy
} from './objProxySetting.js';
$MB.importHandle('objProxySetting', h_objProxy);
//-------------
$MB.export(function() {
	return this.get('makeDataReactive');
});

export default $MB;
