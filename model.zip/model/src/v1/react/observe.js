let $MB;

let $uid = 0;
const $reg_1 = /(\.length)$/;

class ObserveNode {
  $id;

  // 原本的數據
  $raw;
  // proxy
  $proxy;
  $parent;
  // 新的屬性,要往下傳播訊息用的
  $childs = new Set();

  // 確定 data 的型別
  $isArray = false;
  //--------
  // 是否有 arrayMethod 執行
  $arrayMethod;
  // 特殊
  $prevLength;
  //--------
  $models = new Set();
  //--------
  // 只有 root 才有
  // Map()
  $changeList;

  // 傾聽者
  // 爲了避免 listener 記憶體泄漏用
  $listeners = new Set();
  //-------------
  // 當前執行中的 listener
  // []
  $activeListeners;
  //-------------
  // $isTrigger;

  // 當 child 切換位置時會用到
  $isSwitchingPos;

  $keepSilence = false;
  //-----------------------
  constructor(data) {
    // debugger;
    const $bb = $MB.get('bb');
    const $tools = $MB.get('tools');

    this.$id = 'ob_' + $uid++;
    this.$raw = data;

    $tools.dataLinkOb(data, this);

    let proxySetting;
    if (Array.isArray(data)) {
      this.$isArray = true;
      proxySetting = this._initArrayData(data);
    } else if ($bb.$isPlainObject(data)) {
      proxySetting = this._initObjData(data);
    } else {
      throw new Error('...');
    }
    this.$proxy = new Proxy(data, proxySetting);
  }
  //-----------------------
  get id() {
    return this.$id;
  }

  get rawData() {
    return this.$raw;
  }

  get data() {
    return this.$proxy;
  }

  // [] 是否使用了方法
  get arrayMethod() {
    if (!this.$isArray) {
      throw new Error('...');
    }
    return (this.$arrayMethod || null);
  }
  // set [].length 會用到
  get prevLength() {
    if (!this.$isArray) {
      throw new Error('...');
    }
    return this.$prevLength;
  }

  get root() {
    let ob = this;
    let root;
    while (ob != null) {
      root = ob;
      ob = ob.$parent;
    }
    return root;
  }

  get isSilence() {
    // debugger;
    let root = this.root;

    let isSilence = root.$keepSilence;;
    if (isSilence == null || isSilence === false) {
      isSilence = false;
    }
    return isSilence;
  }
  //-----------------------
  // 當 ob 所屬的 data 在同一個 parent 切換位址
  // ob 不用被刪除
  set isSwitchingPos(value) {
    if (!value) {
      this.$isSwitchingPos = undefined;
    } else {
      this.$isSwitchingPos = true;
    }
  }
  // 當 ob 所屬的 data 在同一個 parent 切換位址
  // ob 不用被刪除
  get isSwitchingPos() {
    let res = (this.$isSwitchingPos == true);
    return res;
  }
  //-----------------------
  // 傾聽者
  addListener(listener) {
    this.$listeners.add(listener);
  }

  removeListener(listener) {
    this.$listeners.delete(listener);
  }
  //-----------------------
  // main
  setParent(ob) {
    // debugger;
    if (!(ob instanceof ObserveNode)) {
      throw new Error('...');
    }
    if (this.$parent != null) {
      if (ob.isEqual(this.$parent)) {
        return;
      } else {
        // 不可以隸屬多個數據樹
        throw new Error('...');
      }
    }
    //-------------
    const root = ob.root;
    if (this._isHasCommited() || root._isHasCommited()) {
      throw new Error('...')
    }
    // 只有 commit 才會有 activeListeners
    this.$activeListeners = undefined;
    // debugger;
    if (this.$changeList != null) {
      // 把資料移轉給 parent
      for (let [ob, keyList] of this.$changeList) {
        for (let key of keyList) {
          root._addChangeList(ob, key);
        }
        keyList.clear();
        this.$changeList.delete(ob);
      }
      this.$changeList = undefined;
    }
    //-------------
    this.$parent = ob;
    ob.$childs.add(this);
  }
  //-----------------------
  // sub
  silence(silence) {

    if (silence == null) {
      silence = false;
    }
    let check = silence + '';

    // 參數格式監察
    switch (check) {
      // 對於數據的讀取，修改都不反應
      case 'true':
      // 恢復原設定
      case 'false':
      // 不對 set 有反應
      case 's':
      // 不對 get 有反應
      case 'r':
        break;
      default:
        // 不對的格式
        throw new Error('...');
        return;
    }
    let root = this.root;
    let value = root.$keepSilence;
    root.$keepSilence = silence;
    return value;
  }
  //-----------------------
  // main
  // 與 parent 斷除關係
  remove() {
    debugger;
    const $tools = $MB.get('tools');

    if (this.$parent == null) {
      return;
    }
    //-------------
    if (this.isSwitchingPos == true) {
      // 特殊狀況
      // 不是真的要 remove
      // 而是要 child 交換位置
      // this.isSwitchingPos = undefined;
      return;
    }
    //-------------
    // 通知其 childs
    // 節省記憶體
    for (let child of this.$childs) {
      debugger;
      child.remove();
      this.$childs.delete(child);
    }
    //-------------
    this._destroy();
  }
  //-----------------------
  // sub
  isEqual(ob) {
    if (!(ob instanceof ObserveNode)) {
      return false;
    }
    return (this.$id == ob.$id);
  }
  //-----------------------
  // main
  // 由 proxy 呼叫
  emit(args = {}) {
    // debugger;
    let {
      key,
      action,
      ob,
    } = args;

    if (action == 'read') {
      // debugger;
      let listener = this.curretActiveListener();
      if (listener != null) {
        listener.addWatch(ob, key);
      }
    } else {
      // debugger;
      let root = this.root;
      root._addChangeList(ob, key);
    }
  }
  //-----------------------
  // main
  commit() {
    if (this.$parent != null) {
      // 回朔到 root
      return this.root.commit();
    }
    //-------------
    // root
    debugger;
    // 針對非同步狀況
    if (this._isHasCommited()) {
      // 已經進入 commit 狀態，不需要重複 commit
      return this.$commitHandle.promise;
    } else {
      const ObCommitHandle = $MB.get('ObCommitHandle');
      this.$commitHandle = new ObCommitHandle(this);
    }
    //-------------
    let pr = (async () => {
      const commitHandle = this.$commitHandle;

      while (true) {
        debugger;
        // 迴圈最主要迴圈的目的
        // 怕 commit 周期內有人修改了數據
        if (this.$changeList == null || this.$changeList.size == 0) {
          break;
        }
        // 複製 this.$changeList 並清除記錄
        let changeList = this._copyChangeList();

        // 主要任務
        // 通知大家數據變了
        this._commit(changeList, commitHandle);

        debugger;
        // 等待 _commit() 激發的所有任務完成 render()
        await commitHandle.childsPromise;
      } // while

      debugger;
      let handle = this.$commitHandle;
      this.$commitHandle = undefined;
      handle.end();
    })();
    //-------------
    pr.catch((err) => {
      console.dir(err);
      throw err;
    });

    return pr;
  }
  //-----------------------
  // model init 會遺留數據變動的訊息
  // 必須清除
  clearChangeList() {
    if (this.$parent != null) {
      // 往 root 追朔
      let root = this.root;
      root.clearChangeList();
      return;
    }
    //-------------
    if (this.$changeList != null) {
      for (let [ob_id, keyList] of this.$changeList) {
        keyList.clear();
        this.$changeList.delete(ob_id);
      }
    }
  }
  //-----------------------
  // main
  addModel(model) {
    this.$models.add(model);
  }
  //-----------------------
  // 關於 listener

  // 會往 rootOb 傳送
  addActiveListener(obj) {
    // debugger;
    if (this.$parent != null) {
      // 往上回朔
      let root = this.root;
      root.addActiveListener(obj);
      return;
    }
    //-------------
    if (this.$activeListeners == null) {
      this.$activeListeners = [];
    }
    this.$activeListeners.push(obj);
  }
  //-----------------------
  // 會往 rootOb 傳送
  removeActiveListener(obj) {
    if (this.$parent != null) {
      // 往上回朔
      let root = this.root;
      root.removeActiveListener(obj);
      return;
    }
    //-------------
    let obj_1 = this.$activeListeners.pop();
    if (!obj_1.isEqual(obj)) {
      throw new Error('...');
    }
  }
  //-----------------------
  curretActiveListener() {
    // debugger;
    if (this.$parent != null) {
      // 往上回朔
      let root = this.root;
      return root.curretActiveListener();
    }
    //-------------
    if (this.$activeListeners == null) {
      return null;
    }
    let length = this.$activeListeners.length;
    if (length == 0) {
      return null;
    }
    return this.$activeListeners[length - 1];
  }
  //-----------------------
  addExecutListeners(obj) {
    // debugger;
    if (this.$parent != null) {
      // 往上回朔
      let root = this.root;
      return root.addExecutListeners(obj);
    }
    //-------------
    if (this.$commitHandle == null) {
      return;
    }
    this.$commitHandle.addExecutListener(obj);
  }
  //-----------------------
  // listener 是否執行過
  hasExecut(obj) {
    if (this.$parent != null) {
      // 往上回朔
      let root = this.root;
      return root.hasExecut(obj);
    }
    //-------------
    if (this.$commitHandle == null) {
      return false;
    }
    return this.$commitHandle.hasExecut(obj);
  }
  //-----------------------
  isHasModel(model) {
    debugger;
    let res = false;
    for (let m of this.$models) {
      if (m.isEqaul(model)) {
        res = true;
        break;
      }
    } // for
    return res;
  }
  //-----------------------
  // 是否有 model 傾聽自己
  hasModel() {
    debugger;
    return (this.$models.size > 0);
  }

  //-----------------------
  // setProxy
  _initArrayData(data) {
    // debugger;
    const getArrayProto = $MB.get('getArrayProto');
    const arrayProto = getArrayProto();
    Reflect.setPrototypeOf(data, arrayProto);

    const arrayProxySetting = $MB.get('arrayProxySetting');
    return arrayProxySetting(this);
  }
  //-----------------------
  // setProxy
  _initObjData() {
    // debugger;
    const objProxySetting = $MB.get('objProxySetting');
    return objProxySetting(this);
  }
  //-----------------------
  // model.addChange()
  addChange(path) {
    debugger;
  }
  //-----------------------
  // top down 的過程
  _commit(changeList, handle) {
    debugger;

    console.log(this.$id);

    // child observe
    for (let ob of this.$childs) {
      ob._commit(changeList, handle);
    }
    //-------------
    // 監聽自己的 model
    for (let model of this.$models) {
      // model 呼叫 listener
      debugger;
      model.$$$dataChanged(changeList, handle);
    }
  }
  //-----------------------
  _destroy() {
    this.$parent.$childs.delete(this);
    this.$parent = undefined;
    //--------
    for (let listener of this.$listeners) {
      debugger;
      listener.removeWatch(this);
      this.$listeners.delete(listener);
    }
    //-------------
    for (let model of this.$models) {
      debugger;
      model.$$$remove();
      this.$models.delete(model);
    }
    //--------
    for (let key in this) {
      if (!this.hasOwnProperty(key)) {
        continue;
      }
      this[key] = undefined;
      delete(this[key]);
    }
  }
  //-----------------------
  _copyChangeList() {
    // 複製 this.$changeList 並清除記錄
    let cloneData = new Map();

    for (let [ob, keyList] of this.$changeList) {
      let cloneList = new Set(keyList);
      keyList.clear();
      cloneData.set(ob, cloneList);
      this.$changeList.delete(ob);
    }
    return cloneData;
  }
  //-----------------------
  _addChangeList(ob, key) {

    if (this.$parent != null) {
      throw new Error('...');
    }

    if (this.$parent != null) {
      throw new Error('...');
    }

    if (this.$changeList == null) {
      this.$changeList = new Map();
    }
    if (!this.$changeList.has(ob)) {
      this.$changeList.set(ob, new Set());
    }
    let list = this.$changeList.get(ob);
    list.add(key);
  }
  //-----------------------
  _isHasCommited() {
    // 針對同步狀況
    let res = (this.$commitHandle != null);

    if (res) {
      // 針對非同步
      return true;
    }
    //-------------
    if (this.$activeListeners != null && this.$activeListeners.length > 0) {
      // 針對同步
      // 避免套嵌
      return true;
    }
    return false;
  }
} // class

////////////////////////////////////////

function getObserve(data) {
  const $tools = $MB.get('tools');
  return $tools.getObserve(data);
}
//-----------------------

export function handle(mb) {
  $MB = mb;
  return ObserveNode;
}
