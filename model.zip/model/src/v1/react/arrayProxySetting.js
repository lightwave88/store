let $MB;
//makeDataReactive

const $reg_1 = /^length$/;
const $reg_2 = /^\d+$/;
//------------------
function arrayProxySetting($this) {

	const $tools = $MB.get('tools');
	const $makeDataReactive = $MB.get('makeDataReactive');

	return {
		// get
		get(target, key) {
			console.log(`array.get(${$toString(key)})`);
			if (_isGetRawdata(key)) {
				return target;
			}
			if (typeof(key) == 'symbol') {
				return target[key];
			}
			//-------------
			// debugger;
			let value = target[key];
			let ob = _getOb(target);
			_emit('get', ob, target, key);
			return value;
		},
		// set
		set(target, key, value) {

			console.log(`array.set(${$toString(key)})`);
			debugger;

			let prevValue = target[key];
			if (prevValue === value) {
				return true;
			}
			//--------
			let ob = _getOb(target);
			let prevOb = _getOb(prevValue);

			const isLengthKey = $reg_1.test(key);
			const isIndexKey = $reg_2.test(key);
			const $hasArrayMethod = (ob.arrayMethod != null);

			let arg = null;

			if (isLengthKey) {
				// 修改 length

				if ($hasArrayMethod) {
					prevValue = ob.prevLength;
					arg = [prevValue, value];
				} else {
					// 直接變動 array.length
					arg = [prevValue, value];
					_setLength(target, ob, arg);
				}

				Reflect.set(target, key, value)

				target[key] = value;
			} else if (isIndexKey) {
				debugger;
				// 修改 index

				// 以下步驟順序不能變
				//-------------
				// 步驟1
				// 先做數據連接
				// emit 通道才能順暢
				// target[key] = value;
				//-------------
				// 步驟2
				// init 會有特殊狀況
				if (!$hasArrayMethod && prevOb != null) {
					debugger;
					prevOb.remove( /*value*/ );
				}
				//-------------
				debugger;
				// 步驟3
				let {
					proxy = null,
						value: $value,
				} = $makeDataReactive(value, $this);

				let setValue = (proxy != null) ? proxy : $value;
				Reflect.set(target, key, setValue);
			}
			//-------------
			_emit('set', ob, target, key, arg);
			return true;
		},
		// has
		has(target, key) {

			console.log(`array.has(${$toString(key)})`);
			// GET
			// debugger;

			let ob = _getOb(target);
			let res = Reflect.has(target, key);
			//-------------
			_emit('has', ob, target, key);
			return res;
		},
		// ownKeys
		ownKeys(target) {
			// GET
			console.log('array.ownKeys()');
			// debugger;

			// let ob = _getOb(target);
			let res = Reflect.ownKeys(target);
			//-------------
			// _emit('ownKeys', ob, target, key, []);
			return res;
		},
		// deleteProperty
		deleteProperty(target, key) {
			console.log(`array.delete(${$toString(key)})`);
			debugger;
			let ob = _getOb(target);
			const $hasArrayMethod = (ob.arrayMethod != null);

			let prevValue = target[key];

			let res = Reflect.deleteProperty(target, key);
			if (!res) {
				return res;
			}
			let prevOb = _getOb(prevValue);

			if (!$hasArrayMethod && prevOb != null) {
				prevOb.remove();
			}
			//-------------
			_emit('delete', ob, target, key);
			return res;
		},
	};
}
//----------------------------
function _emit(type, ob, target, key, compareValue = null) {

	const $isSilence = ob.isSilence;
	if ($isSilence !== false) {
		if ($isSilence === true) {
			return;
		} else {
			switch (type) {
				case 'get':
				case 'has':
				case 'ownKeys':
					if ($isSilence === 'r') {
						return;
					}
					break;
				case 'set':
				case 'delete':
					if ($isSilence === 's') {
						return;
					}
					break;
				default:
					throw new Error('...');
					break;
			}
		}
	}
	//-------------
	// debugger;

	// 是否有執行 array.method
	const arrayMethod = ob.arrayMethod;
	// console.log(`arrayMethod: ${arrayMethod}`);

	if (Array.isArray(compareValue)) {
		// 若有比較前後數據前後變化的情景
		let [value1, value2] = compareValue;
		if ((value1 - value2) == 0) {
			return;
		}
	}
	if (key != null) {
		let key_type = typeof(key);

		if (key_type == 'symbol') {
			return;
		}
		//-------------
		if (key == 'length') {
			switch (arrayMethod) {
				case 'at':
					return;
					break;
			} // switch
		}
	}
	//-------------
	// emit...
	// debugger;
	let action;

	switch (type) {
		case 'get':
		case 'has':
		case 'ownKeys':
			action = 'read';
			break;
		case 'set':
		case 'delete':
			action = 'set';
			break;
	}
	//-------------
	// debugger;
	ob.emit({
		key,
		action,
		ob,
	});
}
//----------------------------
function $toString(value) {
	const $tools = $MB.get('tools');
	return $tools.toString(value);
}
//----------------------------
// 判斷 key 是否是要取得 rawData
function _isGetRawdata(key) {
	const $tools = $MB.get('tools');
	return $tools.isGetRawdata(key);
}
//----------------------------
// 取得 observe
function _getOb(data) {
	const $tools = $MB.get('tools');
	return $tools.getObserve(data);
}

//----------------------------
function _hasObserve(data) {
	const $tools = $MB.get('tools');
	return $tools.hasObserve(data);
}
//----------------------------
// 因應直接修改 [].length
function _setLength(target, ob, arg) {
	debugger;

	if (ob.arrayMethod != null) {
		return;
	}
	const $tools = $MB.get('tools');

	let [prevLength, length] = arg;

	if (length < prevLength) {
		// [].delete
		for (let i = length; i < prevLength; i++) {
			debugger;
			let value = target[i];
			let child_ob = $tools.getObserve(value);
			if (child_ob != null) {
				child_ob.remove();
			}
			_emit('delete', ob, target, i, [i]);
		}
	}
}
//----------------------------

export function handle(mb) {
	$MB = mb;
	return arrayProxySetting;
}
