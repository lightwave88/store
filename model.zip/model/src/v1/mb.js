export * from '/my_modules/moduleBridge/index.js';
export { default } from '/my_modules/moduleBridge/index.js';