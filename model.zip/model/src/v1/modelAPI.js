let $MB;

// modelAPI
const $modelAPI = {
	create(data) {
		// debugger;
		const Model = $MB.get('Model');

		if (data instanceof Model) {
			return data;
		}
		let model = new Model(data);
		return model;
	},
	//------------------
	getRawData(data) {
		const $tools = $MB.get('tools');
		let rawData = $tools.getRawData(data);
		return rawData;
	},
	//------------------
	commit(data) {
		debugger;
		const $tools = $MB.get('tools');
		let ob = $tools.getObserve(data);
		if (ob == null) {
			return;
		}
		ob.commit();
	},
	updateList(targetData, newData, idName, compare = true) {
		debugger;
		const $tools = $MB.get('tools');
		$tools.updateList(targetData, newData, idName, compare);
	},
	updateData(targetData, newData, compare = true) {
		debugger;
		const $tools = $MB.get('tools');
		$tools.updateData(targetData, newData, compare);
	},
	getCommitHandle() {
		debugger;
		const CommitHandle = $MB.get('CommitHandle');
		return new CommitHandle();
	},
};
/////////////////////////

$modelAPI.tools = (function () {
	const $toolsAPI = {};
	//------------------
	$toolsAPI['getObserve'] = function (data) {
		let $tools = $MB.get('tools');
		return $tools.getObserve(data);
	};
	//------------------
	return $toolsAPI;
})();
/////////////////////////

export function handle(mb) {
	$MB = mb;
	return $modelAPI;
}
