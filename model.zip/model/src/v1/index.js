// debugger;
import MB from './mb.js';
const $mb = new MB();
//-------------
import {
	handle as h_config
} from './config.js';
$mb.importHandle('config', h_config);
//-------------
import m_tools from './tools/index.js';
$mb.importModule('tools', m_tools);
//-------------
import {
	handle as h_reactAPI
} from './reactAPI.js';
$mb.importHandle('reactAPI', h_reactAPI);
//-------------
import {
	handle as h_modelAPI
} from './modelAPI.js';
$mb.importHandle('modelAPI', h_modelAPI);
//-------------
import m_makeDataReactive from './react/index.js';
$mb.importModule('makeDataReactive', m_makeDataReactive);
//-------------
import m_model from './model/index.js';
$mb.importModule(['Model', 'createListener'], m_model);
//-------------
import {
	handle as h_commit
} from './commitHandle.js';
$mb.importHandle(['CommitHandle', 'ObCommitHandle'], h_commit);
//-------------
export function handle(bb) {
	$mb.import('bb', bb);
	let reactAPI = $mb.get('reactAPI');
	let modelAPI = $mb.get('modelAPI');

	bb['reactive'] = reactAPI;
	bb['$reactive'] = reactAPI;
	
	bb['model'] = modelAPI;
	bb['$model'] = modelAPI;
}
