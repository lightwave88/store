let $MB;
const $extend = {};
//--------------------------------------
{
	$extend.updateData = function (oldData, newData) {
		debugger;
		new UpdateData(oldData, newData);
	};
	//-----------------------
	class UpdateData {
		// $isCompare;
		//-----------------------
		constructor(oldData, newData) {
			debugger;

			// this.$isCompare = !!isCompare;

			let oldType = this._getType(oldData);
			let newType = this._getType(newData);

			switch (newType) {
				case '[object Object]':
				case '[object Array]':
					break;
				default:
					throw new TypeError('...');
					break;
			}
			if (oldType != newType) {
				throw new TypeError('...');
			}
			this._main(oldData, newData);

			console.log(JSON.stringify(oldData));
			console.log(JSON.stringify(newData));
		}
		//-----------------------
		_main(oldData, newData) {
			debugger;
			const $tools = $MB.get('tools');
			let $loopList = [];

			$loopList.push({
				old: oldData,
				new: newData,
			});

			let ob = $tools.getObserve(oldData);
			ob.silence('r');
			//-------------
			this._loopData($loopList);

			this._compare($loopList);
			//-------------
			ob.silence(false);
		}
		//-----------------------
		// 採用廣度優先去蒐集配對數據
		_loopData($loopList) {
			let i = 0;
			while (i < $loopList.length) {
				debugger;
				let data = $loopList[i++];
				let {
					old: oldValue,
					new: newValue,
					key = null,
				} = data;

				if (key != null) {
					// key == null 是 root
					oldValue = oldValue[key];
					newValue = newValue[key];
				}
				let oldType = this._getType(oldValue);
				let newType = this._getType(newValue);
				//-------------
				if (newType == '[object Array]') {
					if (oldType == newType) {
						data.iscontainer = true;

						// 去除掉 oldValue 未來不會有的資料
						this._compareArrayLength(oldValue, newValue);
						debugger;
						for (let i = 0; i < newValue.length; i++) {
							debugger;
							$loopList.push({
								old: oldValue,
								new: newValue,
								key: i,
							});
						}
						continue;
					}
				} else if (newType == '[object Object]') {
					if (oldType == newType) {

						data.iscontainer = true;
						// 去除掉 oldValue 未來不會有的資料
						this._compareObjLength(oldValue, newValue)
						debugger;
						for (let key in newValue) {
							debugger;
							$loopList.push({
								old: oldValue,
								new: newValue,
								key,
							});
						}
						continue;
					}
				}
				//-------------
			} // while
		}
		//-----------------------
		_compare(loopList) {
			debugger;

			while (loopList.length > 0) {
				debugger;
				const {
					old: oldData,
					new: newData,
					key,
					iscontainer = false,
				} = loopList.pop();

				if (key == null) {
					// root 不用比較
					continue;
				}

				if (iscontainer) {
					// 是 {...} [...]不用比較
					continue;
				}

				oldData[key] = newData[key];
				/*
				if (!this.$isCompare) {
					// 不需要比較數值是否相同。直接更新數據
					oldData[key] = newData[key];
				} else {
					let oldValue = oldData[key];
					let newValue = newData[key];

					if (oldValue == undefined || oldValue !== newValue) {
						oldData[key] = newData[key];
					}
				}
				*/
			}
		}
		//-----------------------
		_getType(data) {
			return Object.prototype.toString.call(data);
		}
		//-----------------------
		_compareArrayLength(oldValue, newValue) {
			// debugger;

			while (oldValue.length > newValue.length) {
				// debugger;
				oldValue.pop();
			}
		}
		//-----------------------
		// 去除掉 oldValue 未來不會有的資料
		_compareObjLength(oldValue, newValue) {
			// debugger;

			let oldKeys = Object.keys(oldValue);
			let newKeys = Object.keys(newValue);

			for (let i = 0; i < oldKeys.length; i++) {
				// debugger;
				let key = oldKeys[i];
				if (!newKeys.includes(key)) {
					delete (oldValue[key]);
				}
			} // for
		}
	}
}
//--------------------------------------
export function handle(mb) {
	$MB = mb;
	return $extend;
}