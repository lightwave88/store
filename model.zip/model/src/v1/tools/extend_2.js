let $MB;
const $extend = {};
//--------------------------------------
{
	// 可以取得 data 但不驚擾 proxy
	$extend.getDataByPath = function (data, path, keepSilence = false) {
		// debugger;
		const $tools = $MB.get('tools');

		let pathList;
		if (path == null) {
			pathList = [];
		} else if (typeof (path) == 'string') {
			path = this.regulePath(path);
			if (path == null) {
				pathList = [];
			} else {
				pathList = path.split('.');
			}
		} else if (Array.isArray(path)) {
			pathList = path;
		} else {
			throw new TypeError('...');
		}
		//--------
		let res;
		let ob = $tools.getObserve(data);
		if (ob != null && keepSilence) {

			ob.silence(true);
			res = getData(data, pathList);
			ob.silence(false);
		} else {
			res = getData(data, pathList);
		}
		return res;
	};
	//-----------------------
	function getData(data, pathList) {
		// debugger;

		const $tools = $MB.get('tools');
		//-------------
		while (pathList.length > 0) {
			// debugger;
			if (typeof (data) != 'object' || data == null) {
				break;
			}
			let key = pathList.shift();
			//-------------
			// get data class
			let rawData;

			let ob = $tools.getObserve(data);
			if (ob != null) {
				rawData = $tools.getRawData(data);
			} else {
				rawData = data;
			}
			let _class = $tools.getClass(rawData);
			//-------------
			// debugger;
			switch (_class) {
				case '[object Object]':
					data = data[key];
					break;
				case '[object Array]':
					key = parseInt(key, 10);
					data = data[key];
					break;
				default:
					data = undefined;
					break;
			} // switch
			//------------------
		} // while
		return data;
	}
}

//--------------------------------------
(() => {
	{
		// 更新一羣物件的資料
		$extend.updateList = function (oldData, newData, idName = null) {
			debugger;

			if (this.getObserve(oldData) == null) {
				throw new Error('...');
			}
			//-------------
			let type_1 = this.getClass(oldData);
			let type_2 = this.getClass(newData);
			if (type_1 != type_2) {
				throw new Error('...');
			}
			//-------------
			debugger;
			let compare;
			switch (type_1) {
				case '[object Object]':
					if (idName == null) {
						compare = new FindObj(oldData, newData)
					} else {
						compare = new FindObj_1(oldData, newData, idName);
					}
					break;
				case '[object Array]':
					if (idName == null) {
						compare = new FindArray(oldData, newData);
					} else {
						compare = new FindArray_1(oldData, newData, idName);
					}
					break;
				default:
					throw new Error('...');
					break;
			} // switch
			//-------------
			compare.main();
		}
	}
	///////////////////////////////////
	class $UpdateData {
		$newData;
		$oldData;
		//-----------------------
		constructor(oldData, newData) {
			this.$oldData = oldData;
			this.$newData = newData;
		}
		//-----------------------
		_noRemove(data, judge) {
			// debugger;
			
			let ob = this._getOb(data);
			if (ob == null) {
				return;
			}
			ob.isSwitchingPos = judge;
		}
		//-----------------------
		_getOb(data) {
			const $tools = $MB.get('tools');
			let ob = $tools.getObserve(data);
			return ob;
		}
		//-----------------------
		_destory() {
			setTimeout(() => {
				for (const key in this) {
					if (this.hasOwnProperty(key)) {
						delete (this[key]);
					}
				}
			});
		}
	}
	///////////////////////////////////
	class FindObj extends $UpdateData {
		//-----------------------
		main(){
			debugger;

			const $tools = $MB.get('tools');

			let oldData = this.$oldData;
			let newData = this.$newData;

			const ob = this._getOb(oldData);
			if(ob == null){
				throw new Error('...');
			}
			ob.silence('r');

			let oldKeys = Object.keys(oldData);
			let newKeys = Object.keys(newData);

			let i = 0;
			while(oldKeys.length > 0){
				let key = oldKeys.pop();
				if(!newKeys.includes(key)){
					delete(oldKeys[key]);
				}
			}
			//-------------
			for (let key in newData) {
				if(key in oldData){
					$tools.updateData(oldData[key], newData[key]);
				}else{
					oldData[key] = newData[key];
				}
			}

			ob.silence(false);

			this._destory();
		}
	}
	///////////////////////////////////
	class FindObj_1 extends $UpdateData {
		$idName;
		$caches = new Set();
		$updatedKeys = new Set();
		//-----------------------
		constructor(oldData, newData, idName) {
			super(oldData, newData);
			this.$idName = idName;
		}
		//-----------------------
		main() {
			debugger;
			let oldData = this.$oldData;
			let newData = this.$newData;

			let ob = this._getOb(oldData);
			ob.silence('r');

			debugger;
			let newKeys = this._match(oldData, newData);

			debugger;
			this._deleteOldData(oldData, newKeys);

			ob.silence(false);

			debugger;
			this._update(oldData, newData);
		}
		//-----------------------
		_match(oldData, newData) {
			let newKeys = new Set();

			for (let key_1 in newData) {
				debugger;
				newKeys.add(key_1);
				let newItem = newData[key_1]
				let id_1 = newItem[this.$idName];

				if (key_1 in oldData) {
					let oldItem = oldData[key_1];
					let id_2 = oldItem[this.$idName];
					if (id_1 == id_2) {
						continue;
					}
					this._noRemove(oldItem, true);
					this.$caches.set(oldId, oldItem);
				}

				let find = this._findMatch(id_1, oldData, key_1);
				if (find != null) {
					oldData[key_1] = find;
				} else {
					this.$updatedKeys.add(key_1);
					oldData[key_1] = newItem;
				}
			} // for

			return newKeys;
		}
		//-----------------------
		_findMatch(id_1, oldData, key_1) {
			debugger;

			let find;

			for (let key of this.$caches) {
				debugger;
				let item = this.$caches[key];
				let id_2 = item[this.$idName];
				if (id_1 == id_2) {
					find = item;
					break;
				}
			}
			if (find != null) {
				return find;
			}
			//------------------
			for (let key in oldData) {
				debugger;

				if (this.$updatedKeys.has(key) || key_1 == key) {
					continue;
				}
				let item = oldData[key];
				let id_2 = item[this.$idName];

				if (id_1 == id_2) {
					// 要置換位置
					this._noRemove(oldData[key], true);
					find = oldData[key];
					oldData[key] = null;

					break;
				}
			} // for
			return find;
		}
		//-----------------------
		_update(oldData, newData) {
			debugger;
			const $tools = $MB.get('tools');
			for (let key in newData) {
				if (this.$updatedKeys.has(key)) {
					// 數據已經更新過
					continue;
				}
				this._noRemove(oldData[key], false);
				$tools.updateData(oldData[key], newData[key], this.$isCompare);
			}
		}//-----------------------
		_deleteOldData(oldData, newKeys) {
			debugger;
			for (let key in oldData) {
				if (newKeys.has(key)) {
					newKeys.delete(key);
					continue;
				}
				this._noRemove(oldData[key], false);
				delete (oldData[key]);
			}
			//-------------
			for (let item of this.$caches) {
				debugger;
				this._noRemove(oldData[key], false);
				let ob = this._getOb(item);
				if (ob) {
					ob.remove();
				}
			}
		}
		//-----------------------
		_searchCache(idValue) {
			debugger;
			let find = null;
			for (let i = 0; i < this.$caches.length; i++) {
				debugger;
				let item = this.$caches[i];
				if (item[this.$idName] == idValue) {
					find = item;
					break;
				}
			}
			return find;
		}
		
	}
	///////////////////////////////////
	// 直接用位置匹配
	class FindArray extends $UpdateData {
		//-----------------------
		main() {
			const $tools = $MB.get('tools');

			let oldData = this.$oldData;
			let newData = this.$newData;

			const ob = this._getOb(oldData);
			if(ob == null){
				throw new Error('...');
			}
			ob.silence('r');
			//-------------
			while (oldData.length > newData.length) {
				debugger;
				oldData.pop();
			}
			//-------------
			for (let i = 0; i < newData.length; i++) {
				debugger;
				if (i >= newData) {
					oldData[i] = newData[i];
				} else {
					$tools.updateData(oldData[i], newData[i]);
				}
			}
			//-------------
			ob.silence(false);

			this._destory();
		}
	}
	///////////////////////////////////
	// array 數據的匹配
	// 會去尋找 id 匹配的 item
	class FindArray_1 extends $UpdateData{
		$caches = new Map();
		$idName;
		$hasUpdateKeys = new Set();
		//-----------------------
		constructor(oldData, newData, idName) {
			super(oldData, newData);
			this.$idName = idName;
		}
		//-----------------------
		main() {
			debugger;
			let oldData = this.$oldData;
			let newData = this.$newData;

			if (typeof (this.$idName) != 'string') {
				throw new Error('no set idName');
			}
			const $tools = $MB.get('tools');
			const ob = $tools.getObserve(oldData);
			//-------------
			// debugger;
			ob.silence('r');

			this._match(oldData, newData);

			this._removeItem();

			ob.silence(false);

			// 排序好了
			this._updataData(oldData, newData);

			this._destory();
		}
		//-----------------------
		_match(oldData, newData) {
			debugger;

			const idName = this.$idName;

			for (let i = 0; i < newData.length; i++) {
				debugger;

				if (i >= oldData.length) {
					oldData.push(null);
				}
				//-------------
				let newItem = newData[i];
				let newId = newItem[idName];
				//-------------
				let oldItem = oldData[i];
				let oldId;
				if (oldItem != null && typeof (oldItem) == 'object') {
					debugger;
					oldId = oldItem[idName];
					if (newId == oldId) {
						// 相同位置能夠匹配
						// 不需要動
						continue;
					}
					//-------------
					// 相同位置找不到匹配
					this._noRemove(oldItem, true);
					this.$caches.set(oldId, oldItem);
				}							
				//-------------
				oldItem = this._findMatch(newId, oldData);
				if (oldItem != null) {
					oldData[i] = oldItem;
				} else {
					this.$hasUpdateKeys.add(i);
					// 什麼都沒匹配
					oldData[i] = newData[i];
				}
			} // for
		}
		//-----------------------
		_findMatch(idValue, oldData) {
			debugger;

			const idName = this.$idName;
			let findItem;

			// 先找 cache
			if (this.$caches.has(idValue)) {
				findItem = this.$caches.get(idValue);
				this.$caches.delete(idValue);
				return findItem;
			}
			//-------------
			// 尋找
			for (let j = 0; j < oldData.length; j++) {
				// debugger;

				if (this.$hasUpdateKeys.has(j)) {
					continue;
				}
				let oldItem = oldData[j];

				if (oldItem == null || typeof (oldItem) != 'object' && !(idName in oldItem)) {
					continue;
				}
				let oldId = oldItem[idName];
				if (idValue == oldId) {
					this._noRemove(oldItem, true);
					findItem = oldItem;
					oldData[j] = null;
					break;
				}
			} // for j

			return findItem;
		}
		//-----------------------
		_updataData(oldData, newData) {
			debugger;

			const $tools = $MB.get('tools');

			// 移除沒用的舊 item
			while (oldData.length > newData.length) {
				debugger;
				let index = oldData.length - 1;
				let data = oldData[index];
				this._noRemove(data, false);
				oldData.pop();
			}
			//------------------
			// 更新數據
			for (let i = 0; i < newData.length; i++) {
				debugger;

				if (this.$hasUpdateKeys.has(i)) {
					this.$hasUpdateKeys.delete(i);
					continue;
				}

				let newItem = newData[i];
				let oldItem = oldData[i];

				// reset
				this._noRemove(oldItem, false);

				if (oldItem == null) {
					oldData[i] = newItem;
				} else {
					// 更新數據
					$tools.updateData(oldItem, newItem, this.$isCompare);
				}
			}
			//-------------
			newData.length = 0;
		}
		//-----------------------
		_removeItem() {
			debugger;
			// 移除不用的 data
			console.dir(this.$caches);

			for (let [key, data] of this.$caches) {
				debugger;
				this._noRemove(data, false);
				let ob = this._getOb(data);
				this.$caches.delete(key);
				ob.remove();
			}
		}
	}
})();
//--------------------------------------

export function handle(mb) {
	$MB = mb;
	return $extend;
}
