import MB from '../mb.js';
const $MB = new MB();
//-------------
import {
	handle as h_listener
} from './listener.js';
$MB.importHandle('createListener', h_listener);
//-------------
import {
	handle as h_model
} from './model.js';
$MB.importHandle('Model', h_model);
//-------------
$MB.export(function() {
	const Model = this.get('Model');
	const createListener = this.get('createListener');

	return {
		Model,
		createListener,
	};
});

export default $MB;
