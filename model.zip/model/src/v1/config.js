let $MB;

const $config = {
	'ob_attrName': 'bb_observe',
	'rawData_attrName': 'rawData',
};


export function handle(mb) {
	$MB = mb;
	return $config;
}
