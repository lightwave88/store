// 重要範例

let $data = {
	area: 20,
	child: {
		age: 18,
	}
};
//////////////////////////////
class Listener_1 extends ListenerProto {
	$cacheList = [];
	//------------------
	constructor() {
		debugger;
		super();
		this.model = $bb.model.create($data);
		debugger;
		const $self = this;

		this.model.effect({
			context: this,
			dataUpdate(model) {
				$self.dataUpdate(model);
			}
		})();
	}
	//------------------
	get child() {
		return this.$cacheList[0] || null;
	}
	//------------------
	dataUpdate(model) {
		debugger;
		let newCacheList = [];

		console.log('---------parent start-------');
		let data = model.data;

		console.log(`parent.area = ${data.area}`);

		debugger;
		// 創建 child
		let listener = this.getMode(data.child, this.$cacheList, this.childFactory);

		newCacheList.push(listener);
		console.log('---------parent end-------');

		this.removeOldChild(this.$cacheList);
		this.$cacheList = newCacheList;
	}
	//------------------
	changeArea() {
		debugger;
		let area = $randomValue(500, 1000);
		let data = this.model.data;
		data.area = area;
		this.model.commit();
	}
	//------------------
	changeChild() {
		debugger;
		let data = this.model.data;
		let age = $randomValue(100);
		data.child = {
			age
		};
		this.model.commit();
	}
	//------------------
	childFactory(data) {
		debugger;
		let listener = new Listener_2(data);
		return listener;
	}
}
//////////////////////////////

class Listener_2 extends ListenerProto {
	constructor(data) {
		debugger;
		super();
		this.model = $bb.model.create(data);

		const $self = this;
		debugger;

		this.model.effect({
			context: this,
			dataUpdate(model) {
				debugger;
				$self.dataUpdate(model);
			},
			dataRemove() {
				debugger;				
				$self.dataRemove();
			}
		})();
	}
	//------------------
	dataUpdate(model) {
		debugger;
		let data = model.data;
		console.log('---------child start-------');
		console.log(`child.age = ${data.age}`);
		console.log('---------child end-------');
	}
	//------------------
	changeAge() {
		debugger;
		this.model.data.age = $randomValue(100);
		this.model.commit();
	}
	//------------------
	remove(){
		debugger;
		console.log('remove');
	}

}
