const arrayProto = Array.prototype;
let attrs = Object.getOwnPropertyNames(arrayProto);

const $excludedList = [
  'constructor'
]

const $methods_1 = [
  'find',
  'findIndex',
  'findLast',
  'findLastIndex',
  'includes',
  'indexOf',
  'lastIndexOf'
];
const $methods_2 = [
  'push',
  'pop',
  'shift',
  'unshift',
  'splice',
];

const $methods_3 = ['at'];

let excludedList_1 = $excludedList.concat($methods_1).concat($methods_2).concat($methods_3);

while(attrs.length > 0){
  debugger;
  
  let key = attrs.pop();
  if (excludedList_1.includes(key)) {
    continue;
  }
  if (typeof (arrayProto[key]) != 'function') {
    continue;
  }
  console.log(key);
}

console.dir(excludedList_1);