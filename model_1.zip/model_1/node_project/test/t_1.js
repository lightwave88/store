
class L {
  static $UID = 0;
  $id;
  constructor() {
    this.$id = L.$UID++;
    console.log(this.$id);
  }
}

new L();

new L();