debugger;
import $bb from '/my_modules/bb_core/index.js'

import {
	handle as h_model
} from '/my_modules/simpleModel_2/index.js';
h_model($bb);
//------------------
import {
	handle as h_view
} from '/my_modules/simpleView/index.js';
h_view($bb);
//------------------
window['$bb'] = $bb;
