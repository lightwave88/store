window['$randomValue'] = function (value = 1) {
  value = Math.random() * value;
  value = Math.floor(value);
  return value;
};
