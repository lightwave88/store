debugger;
import $bb from '/my_modules/bb_core/index.js'

import { handle as h_simpleModle } from '/my_modules/simpleModel_2/index.js';

h_simpleModle($bb);

window['$bb'] = $bb;
