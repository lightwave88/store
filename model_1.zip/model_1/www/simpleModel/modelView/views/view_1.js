const $bb = window['$bb'];

const View_1 = $bb.view.extend({	
	render($model) {
		console.log(`......parent(${this.$id}) render()`);
		debugger;
		for (let i = 0; i < this.data.childs.length; i++) {
			debugger;
			let d = this.data.childs[i];
			let _d = $model.getRawData(d)
			let childView = this.createView('b', _d.id, d);
			this.write(childView.html());
			//-------------
			this._buildDom();
		}
	},
	_buildDom() {
		let content = this.html();		
		if (this.el != null) {
			this.el.innerHTML = content;
		} else {
			console.log(content);
		}
	},
});
/////////////////////////////////////////////
const View_2 = $bb.view.extend({
	
	render() {
		console.log(`......child(${this.$id}) render()`);
		debugger;
		let data = this.data;

		let {
			id,
			name,
			age,
		} = data;

		let content = `<div>
    <p>id = ${id}</p>
    <p>name = ${name}</p>
    <p>age = ${age}</p>
    </div>`;
		this.write(content);
	},
});

debugger;
$bb.view.add('a', View_1);
$bb.view.add('b', View_2);

export default undefined;
