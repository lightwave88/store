import {
  $bb
} from './bb_core.js';

// config
import {
  handle as h_config
} from './config.js';
h_config($bb);

// env
import {
  handle as h_env
} from './env.js';
h_env($bb);

export {
  $bb
};
