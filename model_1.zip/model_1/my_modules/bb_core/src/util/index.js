import {
	handle as h_util
} from './util.js';
//-----------------------
function handle(bb) {
	bb.util = {};
	h_util(bb);
}

// 對外界面
export {
	handle
};