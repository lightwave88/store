import {
	handle as h_extend
} from './extend.js';
//---------------------------------
// 對外界面
export function handle(bb) {
	h_extend(bb);
}
