debugger;

import {
	ModuleBridge
} from '../moduleBridge.js';

const $MB = new ModuleBridge();
//-----------------------
import {
	handle as h_a
} from './a.js';

$MB.importHandle('a', h_a);
//-----------------------
import m_bc from './bc/index.js';
$MB.import({
	'b': 'b_1',
	'c': 'c_1'
}, m_bc);
//-----------------------
// 對外輸出
function handle(outsideMoudule) {
	debugger;
	// 引入外部 outsideMoudule
	$MB.import('outside', outsideMoudule);

	debugger;
	$MB.finish();

	const a = $MB.get('a');
	const b = $MB.get('b_1');
	const c = $MB.get('c_1');

	return {
		a,
		b,
		c
	};
}

export {
	handle
};