// browser
export * from '../moduleBridge/index.js';
export {
	default
} from '../moduleBridge/index.js';
