// 創建一個 child_viewClass
let viewClass_1 = $bb.view.extend({
    dataUpdate(store) {
        this.render();
    },
    render(store) {
        const data = store.data;
        let content = 'child head\n';
        content += `child.data = ${JSON.stringify(data)}\n`;
        this.write(content);
    },
});

let childViewName;

// 登錄這個 child_viewClass
$bb.view.add(childViewName, viewClass_1);
//--------------------------------------
// 創建一個 rootView
let view = $bb.view.create({
    dataUpdate(store) {
        this.render();
    },
    render(store) {
        const data = store.data;
        let content = '';
        content += `root head\n`;
        content += `root.data = ${JSON.stringify(data)}\n`;
        content += '--------------------\n';
        this.write(content);
        for (let k in data) {
            let view = this.createView(childViewName, k);
            view.setModel(data[k]);
            content += view.html(this);
        }
        // content = '--------------------\n';
        content += 'root foot';
        this.write(content);
    }
});
view.setStore();
