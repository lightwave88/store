import MB from './mb.js';
const $mb = new MB();

import {
	handle as h_api
} from './api.js';
$mb.importHandle('api', h_api);
//------------------
import {
	handle as h_view
} from './view.js';
$mb.importHandle('View', h_view);
//------------------
export function handle(bb) {
	$mb.import('bb', bb);
	const api = $mb.get('api');
	bb['view'] = api;
}
