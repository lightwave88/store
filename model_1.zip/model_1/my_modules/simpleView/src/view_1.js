let $MB;
let $UID = 0;

class View {
	$id;
	// rootDom
	$element;
	$model;

	$callbacks = {
		remove: null,
		render: null,
		init: null,
	};
	//--------
	// cache
	// {viewClass => {id: view}}
	$cache_childViews = {};
	$new_cache;
	//--------
	// 文本內容
	$contentList = [];
	//--------
	// 鏈接用的資料
	$parent;
	$childs = new Set();

	$identifyName;
	$identifyKey;
	//---------------------------------
	constructor(data = {}, args = {}) {
		// debugger;
		this.$id = 'view_' + $UID++;

		// element
		this.$__checkElement(args);
		//--------
		// extend
		for (let key in this.$callbacks) {
			let value = args[key];
			if (typeof(value) == 'function') {
				this.$callbacks[key] = value;
			}
			delete(args[key]);
		}

		for (let key in args) {
			let value = args[key];
			if (key in this) {
				throw new Error(`key(${key}) exists`);
			} else {
				this[key] = args[key];
			}
		}
		//--------
		// init
		let fn = this.$callbacks['init'];
		if (fn != null) {
			fn.call(this, this.model);
		}
		//--------
		// render
		this.$__setModel(data);
	}
	//---------------------------------
	set el(dom) {
		debugger;
		this.$element = dom;
	}

	get el() {
		return this.$element;
	}

	get data() {
		if (this.$model == null) {
			return;
		}
		return this.$model.data;
	}

	get model() {
		return this.$model;
	}

	get isView() {
		return true;
	}
	//---------------------------------
	setParent(parent, name, key) {
		this.$parent = parent;
		this.$identifyName = name;
		this.$identifyKey = key;
	}
	//---------------------------------
	// callback
	dataUpdate(store) {
		// debugger;
		this.render();
	}
	//---------------------------------
	// callback
	dataRemove() {
		this.remove();
	}
	//---------------------------------
	// callback
	render() {
		debugger;
		// reset
		this.$contentList.length = 0;
		const prev_childs = Array.from(this.$childs);
		this.$childs.clear();
		//----------
		let fun = this.$callbacks['render'];
		if (fun != null) {

			if (this.el) {
				// 若沒有 this.el 則是靠輸出 string
				this.el.innerHTML = '';
			}
			// render
			fun.call(this, this.$model);
		}
		//----------
		// 整理 cache
		this.$__checkCache();

		this.$__checkChilds(prev_childs);
	}
	//---------------------------------
	remove() {
		debugger;

		console.log(`view(${this.$id}) removed.....`);
		if (this.$parent == null) {
			// 已經被移除了
			return;
		}
		//-------------
		const parent = this.$parent;
		this.$parent = undefined;

		// 斷去與 parent 的關係
		parent.removeChild(this, this.$identifyName, this.$identifyKey);

		let fun = this.$callbacks['render'];
		if (fun != null) {
			fun.call(this);
		}
		//-------------
		// 通知 childs remove，節省記憶體開銷
		for (let child of this.$childs) {
			child.dataRemove();
		}
		//-------------
		// destory
	}
	//---------------------------------
	write(value) {

		let content;
		if (typeof(value) == 'object') {
			if (value == null) {
				if (typeof(value) == 'undefined') {
					content = 'undefined';
				} else {
					content = 'null';
				}
			} else {
				content = JSON.stringify(value);
			}
		} else {
			content = '' + value;
		}
		this.$contentList.push(content);
	}
	//---------------------------------
	// important
	createView(identifyName, key, data, args = {}) {
		debugger;

		let view = this.$__searchViewCache(identifyName, key);
		debugger;
		if (view != null) {
			console.log(`use oldview(${identifyName}, ${key})`);
			this.$childs.add(view);
			return view;
		}
		//-------------
		console.log(`new view(${identifyName}, ${key})`);
		const $api = $MB.get('api');

		// 取得已登錄的 viewClass
		let $class = $api.get(identifyName);
		if ($class == null) {
			throw new Error(`no this viewClass(${identifyName})`);
		}
		// 創建 view
		view = new $class(data, args);
		view.setParent(this, identifyName, key);
		this.$childs.add(view);
		//-------------
		// 記錄childView用以重複使用
		this.$__addViewCache(identifyName, key, view);
		return view;
	}
	//---------------------------------
	removeChild(childView, name, key = null) {
		debugger;

		this.$childs.delete(childView);
		//-------------
		// cache
		if (key != null) {
			let viewsCache = this.$cache_childViews;

			viewsCache = viewsCache[name];
			if (viewsCache != null) {
				delete(viewsCache[key]);
			}
			if (Object.keys(viewsCache).length == 0) {
				delete(this.$cache_childViews[name]);
			}
		}
	}

	//---------------------------------
	$__setModel(data) {
		// debugger;

		this.$model = $bb.model.create(data);

		const $this = this;
		// debugger;

		this.$model.effect({
			dataUpdate($m) {
				// debugger;
				$this.dataUpdate($m);
			},
			dataRemove() {
				// debugger;
				$this.dataRemove();
			},
		}, this)();
	}
	//---------------------------------
	$__searchViewCache(name, key) {
		debugger;

		let find;

		if (key == null) {
			// 沒有使用 cache
			return find;
		}
		//-------------
		// 新增的 cache
		if (this.$new_cache != null) {
			try {
				// 新增的
				find = this.$new_cache[name][key];
			} catch (e) {}
		}
		if (find == null) {
			try {
				// 舊有的
				find = this.$cache_childViews[name][key];
				// 記錄是否使用過
				find.count++;
			} catch (e) {}
		}
		//-------------
		if (find == null) {
			return null;
		}
		return find.view;
	}
	//---------------------------------
	$__addViewCache(name, key, view) {
		debugger;

		if (key == null) {
			// 沒有使用 cache
			return;
		}

		if (this.$new_cache == null) {
			this.$new_cache = {};
		}
		if (this.$new_cache[name] == null) {
			this.$new_cache[name] = {}
		}
		this.$new_cache[name][key] = {
			view,
			count: 0,
		};
	}
	//---------------------------------
	// 整理 cache
	$__checkCache() {
		debugger;

		// 去除沒用的 cache
		let oldMap = this.$cache_childViews;
		for (let name in oldMap) {
			for (let key in oldMap[name]) {
				let d = oldMap[name][key];
				let {
					count,
					view,
				} = d;

				if (count == 0) {
					// 沒被使用
					delete(oldMap[name][key]);
					view.remove();
				} else {
					// reset 使用次數
					d.count = 0;
				}
			} // for
			//-------------
			let temp = oldMap[name];
			if (Object.keys(temp).length == 0) {
				delete(oldMap[name]);
			}
		} // for
		//-------------
		debugger;

		// 把新的 view 加入 oldCache
		let newMap = this.$new_cache;

		if (newMap != null) {

			for (let name in newMap) {
				if (oldMap[name] == null) {
					oldMap[name] = {};
				}
				for (let key in newMap[name]) {
					let d = newMap[name][key];
					oldMap[name][key] = d;
				} // for
			} // for

			this.$new_cache = undefined;
		}
	}
	//---------------------------------
	// render 之後清除沒用的 child
	$__checkChilds(prev_childs) {
		debugger;
		while (prev_childs.length > 0) {
			let child = prev_childs.pop();
			if (!this.$childs.has(child)) {
				// child 已經不在線上
				child.remove();
			}
		}
	}
	//---------------------------------
	$__checkElement(args) {
		let el = args.el;
		if (el == null) {
			return;
		}
		if (typeof(el) == 'string') {
			el = document.querySelector(el);
		}
		delete(args.el);
		this.$element = el;
	}
	//---------------------------------
	commit() {
		if (this.$model == null) {
			return;
		}
		this.$model.commit();
	}
	//---------------------------------
	html() {
		// debugger;
		let content = this.$contentList.join('');
		return content;
	}
} // class

export function handle(mb) {
	$MB = mb;
	return View;
}
