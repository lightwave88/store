let $MB;

const $viewClassList = {};

const $api = {
	// options = {dataUpdate, dataRemove, render}
	create(options = {}) {
		debugger;
		const View = $MB.get('View');
		let view = new View(options);
		return view;
	},
	//------------------
	// return viewClass
	// options = {dataUpdate, dataRemove, render}
	extend(options = {}) {
		// debugger;
		const View = $MB.get('View');

		return (class extends View {
			constructor(data = {}, options_1 = {}) {
				let args = Object.assign({}, options, options_1);
				super(data, args);
			}
		});
	},
	//------------------
	// 事先登錄 view
	add(name, viewClass) {
		// debugger;
		const View = $MB.get('View');

		console.log(viewClass instanceof View);
		if (!(viewClass instanceof View)) {
			// throw new TypeError('...');
		}
		$viewClassList[name] = viewClass;
	},
	//------------------
	// 取得事先登錄 view
	get(name) {
		let res = null;

		if(name == null){
			res = Object.assign({}, $viewClassList);
		}else {
			if (name in $viewClassList) {
				res = ($viewClassList[name] || null);
			}
		}		
		return res;
	},
	//------------------
	getClass() {
		const View = $MB.get('View');
		return View;
	}

};

export function handle(mb) {
	$MB = mb;
	return $api;
}
