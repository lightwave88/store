import MB from '../mb.js';
const $MB = new MB();
//-------------
import {
	handle as h_makeProxy
} from './makeProxy.js';
$MB.importHandle('makeProxy', h_makeProxy);
//-------------
import {
	handle as h_ob
} from './observe.js';
$MB.importHandle('ObserveNode', h_ob);
//-------------
import {
	handle as h_arrayMethod
} from './arrayMethod.js';
$MB.importHandle('getArrayProto', h_arrayMethod);
//-------------
$MB.export(['makeProxy']);

export default $MB;
