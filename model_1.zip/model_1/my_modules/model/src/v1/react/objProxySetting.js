let $MB;

function getObjProxySetting($this) {

	const $makeProxy = $MB.get('makeProxy');
	const $tools = $MB.get('tools');

	return {
		get(target, key) {
			// debugger;

			if ($this._isGetRawData(key)) {
				// 返回原始資料
				return target;
			}
			//--------
			let value = Reflect.get(target, key);

			$this.emit(target, key, {
				path: [key],
				type: 'get',
			});
			return value;
		},
		set(target, key, value) {
			// debugger;

			if (!$tools.hasObserve(value)) {
				let data = $makeProxy(value, $this);
				value = data.proxy;
			}
			// debugger;
			let isAdd = !(key in target);

			if (!isAdd) {
				let old_ob = $tools.getObserve(target[key]);
				if (old_ob != null) {
					old_ob.remove();
				}
			}

			let res = Reflect.set(target, key, value);
			if (res) {
				$this.emit(target, key, {
					path: [key],
					type: 'set',
				});

				if (isAdd) {
					// 通知數據的長度有變化
					$this.emit(target, value, {
						path: [],
						type: 'set.length',
					});
				}
			}
			return res;
		},
		has(target, key) {
			// debugger;

			let res;
			if ($this._isGetRawData(key)) {
				res = true;
			} else {
				res = (key in target);
			}
			//--------
			$this.emit(target, key, {
				path: [key],
				type: 'has',
			});
			return res;
		},
		ownKeys(target) {
			// 攔截 loop
			// debugger;

			let keys = Reflect.ownKeys(target);

			$this.emit(target, null, {
				path: [],
				type: 'ownKeys',
			});
			//-------------
			return keys
		},
		deleteProperty(target, key) {
			// debugger;

			let value = Reflect.get(target, key);
			let res = Reflect.deleteProperty(target, key);

			if (!res) {
				return res;
			}
			let old_ob = $tools.getObserve(value);
			if (old_ob != null) {
				old_ob.remove();
			}
			//-------------
			$this.emit(target, key, {
				path: [key],
				type: 'del',
			});

			$this.emit(target, key, {
				path: [],
				type: 'del.length',
			});
			return res;
		}
	};
}
