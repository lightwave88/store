let $MB;
let $arrayProtoClone;

{
  const $arrayProto = Array.prototype;
  $arrayProtoClone = Object.create($arrayProto);

  const $arrayMethods = [
    'push',
    'pop',
    'shift',
    'unshift',
    'splice',
    'sort',
    'reverse',
  ];
  //------------------
  function def(obj, attrName, fn) {
    Object.defineProperty(obj, attrName, {
      value: fn,
      writable: false,
      configurable: false,
      enumerable: false,
    });
  }
  //------------------
  $arrayMethods.forEach((method) => {
    // debugger;
    const $origin = $arrayProto[method];

    def($arrayProtoClone, method, function (...args) {
      debugger;
      const $tools = $MB.get('tools');

      const $ob = $tools.getObserve(this);
      $ob.setArrayMethod(method);
      //-------------
      debugger;

      let value = $origin.apply(this, args);
      console.dir(value);
      //-------------
      debugger;
      // job.end();
      $ob.setArrayMethod(method);
      return value;
    }); // def

  }); // for
}
//----------------------------

function getArrayProto() {
  return $arrayProtoClone;
}

export function handle(mb) {
  $MB = mb;
  return getArrayProto;
}
