let $MB;

function linkObserve(data) {
	// debugger;
	const $tools = $MB.get('tools');
	const $config = $MB.get('config');
	const $symbol = $config['ob_attrName'];
	const $bb = $MB.get('bb');

	if (typeof(data) == 'object') {
		if (!(Array.isArray(data) || $bb.$isPlainObject(data))) {
			// 物件只能是兩種格式
			throw new Error('...');
		}
		if ($tools.hasObserve(data)) {
			let ob = $tools.getObserve(data);
			return ob;
		}
	} else {
		// 簡單數值
		return data;
	}
	//------------
	const ObserveNode = $MB.get('ObserveNode');
	let ob = new ObserveNode(data);
	return ob;
}
//-------------------------------------------
function walkArray(data) {
	// debugger;
	let p_ob = getObserve(data);

	for (let i = 0; i < data.length; i++) {
		let value = data[i];
		let {
			proxy
		} = makeProxy(value, p_ob);
		data[i] = proxy;
	}
}
//-------------------------------------------
function walkPlainObject(data) {
	// debugger;
	let p_ob = getObserve(data);

	for (let key in data) {
		// debugger;
		let value = data[key];
		let {
			proxy
		} = makeProxy(value, p_ob);
		data[key] = proxy;
	}
}
//-------------------------------------------
function getObserve(data) {
	const $tools = $MB.get('tools');
	let res = $tools.getObserve(data);
	return res;
}
//-------------------------------------------
// API
function makeProxy(data, parent = null, store = null) {
	// debugger;
	const $bb = $MB.get('bb');
	const ObserveNode = $MB.get('ObserveNode');

	let ob = linkObserve(data);
	if (!(ob instanceof ObserveNode)) {
		// 簡單數據
		return {
			proxy: ob
		};
	}
	// debugger;
	if (store != null) {
		ob.setStore(store);
	}
	if (parent != null) {
		ob.setParent(parent);
	}
	const rawData = ob.$raw;
	const p_data = ob.$proxy;
	//-------------
	// debugger;

	if (Array.isArray(rawData)) {
		walkArray(p_data);
	} else if ($bb.$isPlainObject(rawData)) {
		walkPlainObject(rawData);
	}
	//-------------
	// 重定義 [].proto
	if (Array.isArray(rawData)) {
		const $getArrayProto = $MB.get('getArrayProto');
		const proto = $getArrayProto()
		Reflect.setPrototypeOf(rawData, proto);
	}

	let proxy = ob.$proxy;
	return {
		proxy,
		ob
	};
}
//-------------------------------------------
export function handle(mb) {
	$MB = mb;
	return makeProxy;
};
