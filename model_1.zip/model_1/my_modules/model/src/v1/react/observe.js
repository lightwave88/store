let $MB;

let $uid = 0;
const $noEmitList_1 = ['toJSON'];
const $reg_2 = /^length$/;

class ObserveNode {
	$id;
	$model;

	// 原本的數據
	$raw;
	$proxy;
	$parent;
	// 是否有 arrayMethod 執行
	$arrayMethod;
	//-----------------------
	constructor(data) {
		// debugger;
		const $bb = $MB.get('bb');
		const $tools = $MB.get('tools');

		this.$id = 'ob_' + $uid++;
		this.$raw = data;

		$tools.dataLinkOb(data, this);

		let proxySetting;
		if (Array.isArray(data)) {
			setArrayProto(data);
			proxySetting = getArrayProxySetting(this);
		} else if ($bb.$isPlainObject(data)) {
			proxySetting = getObjProxySetting(this);
		} else {
			throw new Error('...');
		}
		this.$proxy = new Proxy(data, proxySetting);
	}
	//-----------------------
	get data() {
		return this.$raw;
	}
	//-----------------------
	// 數據是否在監控中
	get isTrack() {
		let model = this.$model;
		return model.isTrack;
	}
	//-----------------------
	setStore(store) {
		this.$model = store;
	}
	//-----------------------
	setParent(ob) {
		// debugger;
		if (!(ob instanceof ObserveNode)) {
			throw new Error('...');
		}
		this.$parent = ob;
		this.$model = ob.$model;
	}
	//-----------------------
	remove() {
		this.$model = undefined;
		this.$parent = undefined;
	}
	//-----------------------
	isEqual(ob) {
		if (!(ob instanceof ObserveNode)) {
			return false;
		}
		return (this.$id === ob.$id);
	}
	//-----------------------
	// 往上追根
	// 並通報路徑
	_bubbling(ob, info) {
		// debugger;

		let p_ob = ob.$parent;
		if (p_ob == null) {
			// 到頂了
			// debugger;
			ob.$store.__callByObserve(info);
			// end
			return;
		}
		//------------------
		let {
			path: pathList
		} = info;

		let data = p_ob.$raw;
		if (Array.isArray(data)) {
			for (let i = 0; i < data.length; i++) {
				debugger;
				let value = data[i];
				let _ob = getObserve(value);
				if (_ob.isEqual(ob)) {
					pathList.push(i + '');
					break;
				}
			}

		} else if ($bb.$isPlainObject(data)) {
			for (let key in data) {
				// debugger;
				let value = data[key];
				let _ob = getObserve(value);
				if (_ob != null && _ob.isEqual(ob)) {
					pathList.push(key);
					break;
				}
			}
		} else {
			throw new Error('...');
		}
		//------------------
		this._bubbling(p_ob, info);
	}
	//-----------------------
	// 是否有傾聽者
	hasListner() {
		let listener = this.getListner();
		let res = (listener != null) ? true : false;
		return res;
	}
	//-----------------------
	// 取得 listener
	getListner() {
		const $global = $MB.get('global');
		let res = $global.activeListener;
		return res;
	}
	//-----------------------
	// 是否要取得原始的資料
	_isGetRawData(key) {
		// debugger;

		if (typeof (key) != 'symbol') {
			return false;
		}
		const $tools = $MB.get('tools');
		const $config = $MB.get('config');

		let rawData_attrName = $config['rawData_attrName'];
		rawData_attrName = $tools.symbol(rawData_attrName);

		if (key !== rawData_attrName) {
			return false;
		}
		return true;
	}
	//-----------------------
	emit(target, key, info) {
		if (!this._isEmit(target, key, info)) {
			return;
		}
		this._bubbling(this, info);
	}
	//-----------------------
	// {} 用
	_isEmit(target, key, info) {
		// debugger;
		// let model = this.$model;

		if (!this.isTrack) {
			return;
		}
		//-------------
		let {
			type,
			path
		} = info;

		if (key != null) {
			let key_type = typeof (key);
			switch (key_type) {
				case 'symbol':
					return false;
					break;
				default:
					if ($noEmitList_1.includes(key)) {
						return false;
					}
					break;
			}
		}
		//-------------
		// 資訊整理
		let action;
		let judgeType;
		switch (type) {
			case 'get':
				action = 'GET';
				judgeType = 'read';
				break;
			case 'set':
				action = 'SET';
				judgeType = 'read';
				break;
			case 'set.length':
				action = 'SET';
				judgeType = 'read.length';
				break;
			case 'has':
				action = 'GET';
				judgeType = 'read';
				break;
			case 'ownKeys':
				action = 'GET';
				judgeType = 'read.length';
				break;
			case 'del':
				action = 'SET';
				judgeType = 'read';
				break;
			case 'del.length':
				action = 'SET';
				judgeType = 'read.length';
				break;
			default:
				throw new Error('...');
				break;
		}
		info.judgeType = judgeType;
		info.action = action;
		//-------------
		let hasListner = this.hasListner();
		// for test
		// hasListner = true;

		if (action == 'GET' && !hasListner) {
			return false;
		}
		return true;
	}
	//-----------------------
	// [] 用
	_getValue_2(target, ob, key) {
		// debugger;
		let isEmit = true;
		let value;
		//-------------
		// getValue
		end_1: {
			if (typeof (key) == 'symbol') {
				isEmit = false;
				value = target[key];
			} else if (typeof (key) == 'string') {

				if ($reg_1.test(key)) {
					// JSON
					isEmit = false;
					break end_1;
				}
				value = target[key];

				if (typeof (value) == 'function') {
					isEmit = false;
					break end_1;
				}
			}
		}
		//-------------
		end_2: {
			if (isEmit) {
				if (this.$arrayMethod != null) {
					isEmit = false;
					break end_2;
				}

				if (!this.hasListner()) {
					isEmit = false;
					break end_2;
				}
			}
		}
		//-------------
		return {
			isEmit,
			value,
		}
	}
	//-----------------------
} // class

////////////////////////////////////////
function setArrayProto(data) {

}
//-----------------------
function getObserve(data) {
	const $tools = $MB.get('tools');
	let res = $tools.getObserve(data);
	return res;
}

export function handle(mb) {
	$MB = mb;
	return ObserveNode;
}
