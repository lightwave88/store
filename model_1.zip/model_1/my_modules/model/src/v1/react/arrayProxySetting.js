let $MB;

function arrayProxySetting($this) {

	return {
		get(target, key) {
			// GET
			debugger;

			let {
				value,
				isEmit
			} = $this._getValue_2(target, $this, key);
			//-------------
			debugger;
			if (isEmit) {
				let path;
				let type;

				if ($reg_2.test(key)) {
					// length
					path = [];
					type = 'length';
				} else {
					path = [key];
					type = 'set';
				}

				$this._bubbling($this, {
					path,
					action: 'GET',
					type,
				});
			}
			//-------------
			return value;
		},
		set(target, key, value) {
			debugger;

			if (!$tools.hasObserve(value)) {
				let data = $makeProxy(value, $this);
				value = data.proxy;
			}
			target[key] = value;
			//-------------
			let path;
			let type;
			if ($reg_2.test(key)) {
				// length
				path = [];
				type = 'length';
			} else {
				path = [key];
				type = 'set';
			}
			//-------------
			$this._bubbling($this, {
				path,
				action: 'SET',
				type,
			});
			//-------------
			return true;
		},
		has(target, key) {
			// GET
			debugger;

			let isEmit = (() => {
				if (!$this.hasListner()) {
					return false;
				}
				if (typeof(key) == 'symbol') {
					return false;
				}
				if ($this.$arrayMethod != null) {
					return false;
				}
				return true;
			})();
			//-------------
			if (isEmit) {
				$this._bubbling($this, {
					path: [key],
					action: 'GET',
					type: 'set',
				});
			}
			let res = Reflect.has(target, key);
			return res;
		},
		ownKeys(target) {
			// GET
			debugger;

			let isEmit = (() => {
				if (!$this.hasListner()) {
					return false;
				}
				if ($this.$arrayMethod != null) {
					return false;
				}
				return true;
			})();
			//-------------
			if (isEmit) {
				$this._bubbling($this, {
					path: [],
					action: 'GET',
					type: 'length',
				});
			}
			let res = Reflect.ownKeys(t);
			return res;
		},
		deleteProperty(target, key) {
			debugger;
			let res = Reflect.deleteProperty(target, key);

			if (!res) {
				return res;
			}
			//-------------
			$this._bubbling($this, {
				path: [key],
				action: 'SET',
				type: 'set',
			});

			$this._bubbling($this, {
				path: [],
				action: 'SET',
				type: 'length',
			});

			return res;
		},
	};

}
