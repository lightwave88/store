let $MB;

const $api = {
	create(data) {
		const RootModel = $MB.get('RootModel');
		let res = new RootModel(data);
		return res;
	},
	class(name = null) {
		// 未
	}
};

export function handle(mb) {
	$MB = mb;
	return $api;
}
