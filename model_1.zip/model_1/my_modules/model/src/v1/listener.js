let $MB;
// 判斷類型
const $reg_1 = /^read\.length\|/;
const $reg_2 = /^read\.length$/;
const $reg_3 = /(.*)\+$/;

let $UID = 0;

class Lisener {
	$id;
	$context;
	// 讀取 data 的起始位置
	$store;

	// 傾聽的 stores
	$stores = new Set();
	$fn_update;
	$fn_remove;

	// storeID.type|...path
	$dependPaths = new Set();

	// 是否會受到底層數據變動影響
	// view是不接受
	$includeChildChange = true;

	$isDetected = false;
	//------------------------------------------------
	constructor(store, args = {}) {
		debugger;
		this.$id = 'listener_' + $UID++;
		this.$store = store;

		let {
			context,
			dataUpdate,
			dataRemove,
			bottom,
		} = args;

		if (context != null) {
			this.$context = context;
		}
		if (typeof (dataUpdate) != 'function') {
			throw new TypeError('...');
		}
		this.$fn_update = dataUpdate;

		if (typeof (dataRemove) == 'function') {
			this.$fn_remove = dataRemove;
		}
		if (bottom === false) {
			this.$includeChildChange = false;
		}

		// 連接關係
		store.$listenerList.add(this);
	}
	//------------------------------------------------
	// (系統)會通知與那些 datapath 相依
	addWatch(judgeType, input_path) {
		debugger;

		if ($reg_2.test(judgeType)) {
			// read.length
			this.$dependPaths.add(input_path);
			return;
		}
		//-------------
		let isFind = this._isMatch_1(input_path);
		if (!isFind) {
			this.$dependPaths.add(input_path);
		}
	}
	//------------------------------------------------
	// 當 store 有變動，會呼叫是否有牽連
	isMatch(pathList) {
		// debugger;

		if (!this.$isDetected) {
			// 還沒進行數據依賴的偵測
			return true;
		}

		let res = false;
		find: {
			for (let input_path of pathList) {
				// debugger;
				if ($reg_1.test(input_path)) {
					// read.length

					console.dir(Array.from(this.$dependPaths));
					console.log(input_path);

					if (this.$dependPaths.has(input_path)) {
						res = true;
						break find;
					}
				} else {
					for (let path of this.$dependPaths) {
						// debugger
						if (this._isMatch(input_path, path)) {
							res = true;
							break find;
						}
					} // loop
				}
			} // loop
		}
		return res;
	}
	//------------------------------------------------
	// callback
	dataChanged(options = {}) {

		const $global = $MB.get('global');

		this.$isDetected = true;
		// 重要的地方
		this._clearWatch();
		//-------------
		// let _event = this._getEvent(options);

		$global.addActiveListener(this);

		debugger;
		this.$fn_update.call(this.$context, this.$store);

		debugger;
		{
			console.log(`-----listener(${this.$id}).dataChanged()-----`)
			let test = JSON.stringify(Array.from(this.$dependPaths));
			console.dir(test);
			console.log('----------');
		}

		$global.removeActiveListener();
	}
	//------------------------------------------------
	// API
	// 當依存的數據不在了
	remove() {
		debugger;

		if (this.$fn_remove != null) {
			this.$fn_remove();
		}
		this.removeEffect();
	}
	//------------------------------------------------
	removeEffect() {
		if (this.$store == null) {
			return;
		}
		this.$store = undefined;
		this.$dependPaths.clear();
		store.removeEffect(this);

		this.destroy();
	}
	//------------------------------------------------
	destroy() {

	}
	//------------------------------------------------
	_clearWatch() {
		// debugger;
		this.$dependPaths.clear();
	}
	//------------------------------------------------
	_isMatch(input_path, old_path) {
		// debugger;

		// old_path
		// (type|storeID|path|includeChild)

		let [i_type, i_path] = input_path.split('|');
		let [o_type, o_path, isIncludeChild] = old_path.split('|');

		if (i_type != o_type) {
			return false;
		}
		isIncludeChild = (isIncludeChild.length > 0) ? true : false;
		//-------------
		let input_paths = i_path.split('.');
		let old_paths = o_path.split('.');

		let input_length = input_paths.length
		let old_length = old_paths.length;
		//-------------
		if (this.$includeChildChange || isIncludeChild) {
			// 自己底層數據變動與自己有關
			let $length = Math.min(input_paths.length, old_paths.length);

			for (let i = 0; i < $length; i++) {
				if (input_paths[i] != old_paths[i]) {
					return false;
				}
			}
			return true;
		} else {
			if (input_length > old_length) {
				// 底層的變動若自己沒讀到，則不與自己有關
				// 底層的變動若自己沒讀到，則不與自己有關
				// 底層的變動若自己沒讀到，則不與自己有關
				return false
			}

			for (let i = 0; i < old_length; i++) {
				if (input_paths[i] == null) {
					break;
				}
				if (input_paths[i] != old_paths[i]) {
					return false;
				}
			} // for
			return true;
		}
	}
	//------------------------------------------------
	_isMatch_1(input_path) {
		// 演算法
		// 遇到(a.b, a.b.c)只取最長 a.b.c
		// a.b.c 同樣可以 match (a, a.b, a.b.c)
		// 可以省去記憶空間
		let [i_type, i_path, i_foot] = input_path.split('|');
		let input_paths = i_path.split('.');

		// 注意此步驟
		let cloneData = new Set(this.$dependPaths);

		let isFind = false;
		outside: {
			// 檢查既有的記錄，是否有可以更新的
			for (let old_path of cloneData) {
				// debugger;
				if ($reg_1.test(old_path)) {
					// read.length
					continue;
				}
				let [o_type, o_path, o_foot] = old_path.split('|');

				if (i_foot != o_foot) {
					// 不同羣組
					continue;
				}
				//------------------
				// input_path, old_path 比對
				let isSameType = true;
				let needUpdate = true;

				let old_paths = o_path.split('.');
				for (let i = 0; i < old_paths.length; i++) {
					// debugger;
					if (i >= input_paths.length) {
						// input_paths 比較短
						needUpdate = false;
						break;
					}
					let in_key = input_paths[i];
					let o_key = old_paths[i];

					if (in_key !== o_key) {
						isSameType = false;
						break;
					}
				} // for
				// input_path, old_path 比對完成
				//------------------
				if (!isSameType) {
					continue;
				} else {
					// sametype
					isFind = true;
					if (needUpdate) {
						// 長度長
						this.$dependPaths.delete(old_path);
						this.$dependPaths.add(input_path);
					}
					break outside;
				}
			} // for
		}

		return isFind;
	}
} // class

//---------------------------------

export function handle(mb) {
	$MB = mb;
	return Lisener;
}
