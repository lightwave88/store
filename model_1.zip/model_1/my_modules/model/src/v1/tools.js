let $MB;

const $tools = {};
//--------------------------------------
{
	// 複製 data 的值
	$tools.copyValue = function (data) {
		const $bb = $MB.get('bb');
		let value = $bb.$copyValue(data);
		return value;
	};
}
//--------------------------------------
{
	const $reg_1 = /\[(.+?)\]/;
	const $reg_2 = /(['"])(.+?)\1/;
	const $reg_3 = /^\./;

	$tools.regulePath = function (path) {
		// debugger;

		if (path == null) {
			return null;
		} else if (typeof (path) == 'string') {
			path = path.trim();
			if (path.length == 0) {
				return null;
			}
		} else {
			throw new TypeError('...');
		}
		//-------------
		let reg_1 = RegExp($reg_1, 'g');

		path = path.replace(reg_1, (m, g1) => {
			debugger;

			let word = g1;
			word = word.replace($reg_2, (m, g1, g2) => {
				debugger;
				return g2;
			});
			return `.${word}`;
		});
		// debugger;
		path = path.replace($reg_3, '');

		return path;
	};
}
//--------------------------------------
$tools.getDataKeys = function (data) {
	const $bb = $MB.get('bb');
	let _class = $bb.$getClass(data);

	let keys;

	switch (_class) {
		case 'Object':
			keys = Object.keys(data);
			break;
		case 'Array':
			data.forEach((item, i) => {
				keys.push(i);
			});
			break;
		case 'Map':
			keys = Array.from(data.keys());
			break;
		case 'Set':
		default:
			break;
	}

	if (!Array.isArray(keys)) {
		throw new TypeError('unSupport data type');
	}
	return keys;
};

//--------------------------------------
$tools.getObserve = function (data) {
	// debugger;

	const $bb = $MB.get('bb');
	const $config = $MB.get('config');
	let key = $config['ob_attrName'];
	key = $tools.symbol(key);

	if (!(Array.isArray(data) || $bb.$isPlainObject(data))) {
		return null;
	}

	let res = data[key] || null;
	return res;
};
//--------------------------------------
$tools.hasObserve = function (data) {
	let res = $tools.getObserve();
	return (res != null);
}
//--------------------------------------
$tools.getRawData = function (data) {

	if (typeof (data) != 'object') {
		return data;
	} else if (data == null) {
		return data;
	}

	const $config = $MB.get('config');
	let rawData_attrName = $config['rawData_attrName'];
	rawData_attrName = $tools.symbol(rawData_attrName);

	if (rawData_attrName in data) {
		// proxy data
		data = data[rawData_attrName];
	}
	return data;
}
//--------------------------------------
$tools.isgetRawData = function(key){
	const $config = $MB.get('config');
	let rawData_attrName = $config['rawData_attrName'];
	rawData_attrName = $tools.symbol(rawData_attrName);
	return (key === rawData_attrName);
}

//--------------------------------------
$tools.dataLinkOb = function (data, ob) {
	const $config = $MB.get('config');
	let ob_attrName = $config['ob_attrName'];
	ob_attrName = $tools.symbol(ob_attrName);

	Object.defineProperty(ob.$raw, ob_attrName, {
		value: ob,
		writable: false,
		configurable: false,
		enumerable: false,
	});
};

//--------------------------------------
$tools.functionId = function (fun) {
	return $bb.util.functionId(fun);
};
//--------------------------------------
{
	// 需要
	$tools.symbol = $symbol;
	//------------------
	let $reg_1 = /^Symbol\((.*?)\)$/;
	const $bucket = new Map();

	function $symbol(name) {
		let res;
		if (typeof (name) == 'symbol') {
			res = name.toString();
			res = res.replace($reg_1, (m, g1) => {
				return g1;
			});
		} else if (typeof (name) == 'string') {
			if (!$bucket.has(name)) {
				$bucket.set(name, Symbol(name));
			}
			res = $bucket.get(name);
		}
		return res;
	}
}

//--------------------------------------
export function handle(mb) {
	$MB = mb;
	return $tools;
}
