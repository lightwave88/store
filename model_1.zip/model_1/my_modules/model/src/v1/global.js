let $MB;

let $global = (() => {

	// 全域變數
	class Global {
		// 當前執行的 model
		// 還有避免套嵌的問題
		$activeStoreStock = [];

		// 當前處理中的 listener
		// 還有避免 listenser 套嵌造成的問題
		$activeListenerStock = [];

		// commit() 執行過的 listener
		// 避免 listener 重複執行
		$excutedListenners = new Set();
		//-----------------------
		constructor() {}
		//-----------------------
		// 當前執行的 model
		get activeStore() {
			let index = this.$activeStoreStock.length - 1;
			let res = this.$activeStoreStock[index] || null;
			return res;
		}
		//-----------------------
		// 當前執行的 listener
		get activeListener() {
			let index = this.$activeListenerStock.length - 1;
			let res = this.$activeListenerStock[index] || null;
			return res;
		}
		//-----------------------
		// 當前處理中的 listener
		// 還有避免 listenser 套嵌造成的問題
		addActiveListener(listener) {
			// debugger;
			const Listener = $MB.get('Listener');
			if (!(listener instanceof Listener)) {
				throw new TypeError('...');
			}
			this.$activeListenerStock.push(listener);
		}
		//-----------------------
		removeActiveListener() {
			// debugger;
			this.$activeListenerStock.pop();
		}
		//-----------------------
		addActiveStore(model) {
			const Model = $MB.get('Model');
			if (!(model instanceof Model)) {
				throw new TypeError('...');
			}
			this.$activeStoreStock.push(model);
		}
		//-----------------------
		removeActiveStore() {
			this.$activeStoreStock.pop();
		}
		//-----------------------
		// 防止listener重複執行
		addExcutedListener(listener) {
			this.$excutedListenners.add(listener);
		}
		//-----------------------
		// listener 是否執行過
		isExcuted(listener) {
			return this.$excutedListenners.has(listener);
		}
		//-----------------------
		clearExcutedListeners() {
			this.$excutedListenners.clear();
		}
	} // class

	return new Global();
})();

export function handle(mb) {
	$MB = mb;
	return $global;
}
