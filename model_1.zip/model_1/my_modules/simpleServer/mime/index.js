module.exports = require('./mime.js');
