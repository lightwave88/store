let $MB;

const $tools = {};

//--------------------------------------
{
	// 複製 data 的值
	$tools.copyValue = function (data) {
		const $bb = $MB.get('bb');
		let value = $bb.$copyValue(data);
		return value;
	};
}
//--------------------------------------
$tools.getDataKeys = function (data) {
	const $bb = $MB.get('bb');
	let _class = $bb.$getClass(data);

	let keys;

	switch (_class) {
		case 'Object':
			keys = Object.keys(data);
			break;
		case 'Array':
			data.forEach((item, i) => {
				keys.push(i);
			});
			break;
		case 'Map':
			keys = Array.from(data.keys());
			break;
		case 'Set':
		default:
			break;
	}

	if (!Array.isArray(keys)) {
		throw new TypeError('unSupport data type');
	}
	return keys;
};

//--------------------------------------
$tools.getObserve = function (data) {
	// debugger;

	const $bb = $MB.get('bb');
	const $config = $MB.get('config');
	let key = $config['ob_attrName'];
	key = $tools.symbol(key);

	if (!(Array.isArray(data) || $bb.$isPlainObject(data))) {
		return null;
	}

	let res = data[key] || null;
	return res;
};
//--------------------------------------
$tools.getRawData = function(data){
	let ob = $tools.getObserve(data);
	if(ob == null){
		return data;
	}
	const $config = $MB.get('config');
	let key = $config[rawData_attrName];
	key = $tools.symbol(key);
	return data[key];
}	

//--------------------------------------
$tools.hasObserve = function (data) {	
	let res = $tools.getObserve(data);
	res = (res != null)
	return res;
}
//--------------------------------------
$tools.dataLinkOb = function (data, ob) {
	const $config = $MB.get('config');
	let ob_attrName = $config['ob_attrName'];
	ob_attrName = $tools.symbol(ob_attrName);

	Object.defineProperty(data, ob_attrName, {
		value: ob,
		writable: false,
		configurable: false,
		enumerable: false,
	});
};
//--------------------------------------
{
	$tools.symbol = $symbol;
	//------------------
	let $reg_1 = /^Symbol\((.*?)\)$/;
	const $bucket = new Map();

	function $symbol(name) {
		let res;
		if (typeof (name) == 'symbol') {
			res = name.toString();
			res = res.replace($reg_1, (m, g1) => {
				return g1;
			});
		} else if (typeof (name) == 'string') {
			if (!$bucket.has(name)) {
				$bucket.set(name, Symbol(name));
			}
			res = $bucket.get(name);
		}
		return res;
	}
}
//--------------------------------------

$tools.isGetRawdata = function(_key){
	const $config = $MB.get('config');
	let key = $config['rawData_attrName'];
	key = $tools.symbol(key);
	return (key === _key);
}
//--------------------------------------
export function handle(mb) {
	$MB = mb;
	return $tools;
}
