// debugger;
import MB from './mb.js';
const $mb = new MB();
//-------------
import {
	handle as h_config
} from './config.js';
$mb.importHandle('config', h_config);
//-------------
import {
	handle as h_tools
} from './tools.js';
$mb.importHandle('tools', h_tools);
//-------------
import {
	handle as h_api
} from './api.js';
$mb.importHandle('api', h_api);
//-------------
import m_makeProxy from './react/index.js';
$mb.importModule('makeProxy', m_makeProxy);
//-------------
export function handle(bb) {
	$mb.import('bb', bb);
	let api = $mb.get('api');
	bb['reactive'] = api;
}
