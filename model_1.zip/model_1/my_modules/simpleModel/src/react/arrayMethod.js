/////////////////////////
//
// 測試用
//
/////////////////////////

let $MB;
const $arrayProto = Array.prototype;
let $arrayProtoClone;

function defProperty(obj, attrName, fn) {
	Object.defineProperty(obj, attrName, {
		value: fn,
		writable: false,
		configurable: false,
		enumerable: false,
	});
}
//----------------------------
function getArrayProto() {
	// debugger;
	if ($arrayProtoClone != null) {
		return $arrayProtoClone;
	}
	//----------------------------
	const $tools = $MB.get('tools');

	// init $arrayProtoClone
	$arrayProtoClone = Object.create($arrayProto);

	(() => {
		// 針對 array 的修改方法
		let $arrayMethods = [
			'push',
			'pop',
			'shift',
			'unshift',
			'splice',
			'sort',
			'reverse',
		];

		while ($arrayMethods.length > 0) {
			let method = $arrayMethods.pop();
			const $origin = $arrayProto[method];

			defProperty($arrayProtoClone, method, function(...args) {
				debugger;
				console.log(`array.${method}`);
				console.dir(args);

				let ob = $tools.getObserve(this);
				ob.$arrayMethod = method;
				let value = $origin.apply(this, args);
				ob.$arrayMethod = undefined;
				return value;
			}); // def
		} // while
	})();
	//----------------------------

	(() => {
		debugger;
		// 針對 arrya.search
		let $arrayMethods = [
			'find',
			'findIndex',
			'findLast',
			'findLastIndex',
			'includes',
			'indexOf',
			'lastIndexOf'
		];

		while ($arrayMethods.length > 0) {

			let method = $arrayMethods.pop();
			const $origin = $arrayProto[method];

			defProperty($arrayProtoClone, method, function(...args) {
				debugger;
				console.log(`array.${method}`);
				console.dir(args);

				let ob = $tools.getObserve(this);

				ob.$arrayMethod = method;
				let res = $origin.apply(this, args);
				/*
				if (res === false || res === -1) {
					let rawData = $tools.getRawData(this);
					res = $origin.apply(rawData, args);
				}
				*/
				ob.$arrayMethod = undefined;
				return res;
			}); // def
		} // while
	})();
	//----------------------------
	(() => {
		// 針對 array.iteration

		let $arrayMethods = [
			'map',
			'every',
			'forEach',
			'reduce',
			'reduceRight',
			'filter',
			'some'
		];

		while ($arrayMethods.length > 0) {

			let method = $arrayMethods.pop();
			const $origin = $arrayProto[method];

			defProperty($arrayProtoClone, method, function(...args) {
				debugger;
				console.log(`array.${method}`);
				console.dir(args);

				let ob = $tools.getObserve(this);

				ob.$arrayMethod = method;
				let res = $origin.apply(this, args);
				ob.$arrayMethod = undefined;
				return res;
			}); // def
		} // while
	})();
	//----------------------------
	return $arrayProtoClone;
}
//------------------
export function handle(mb) {
	$MB = mb;
	return getArrayProto;
}
