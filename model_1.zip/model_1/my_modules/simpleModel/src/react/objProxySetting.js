let $MB;

const toString = function(value){
	try {
		value = value.toString();
	} catch (e){
		value = ('' + value);
	}
	return value;
}
//------------------
function $objProxySetting($this) {

	const $makeProxy = $MB.get('makeProxy');
	const $tools = $MB.get('tools');

	return {
		get(target, key) {
			debugger;

			console.log(`obj.get(${toString(key)})`);
			if ($tools.isGetRawdata(key)) {
				return target;
			}

			let value = Reflect.get(target, key);
			return value;
		},
		set(target, key, value) {
			debugger;

			console.log(`obj.set(${toString(key)})`);
			if (!$tools.hasObserve(value)) {
				let data = $makeProxy(value, $this);
				value = data.proxy;
			}
			debugger;
			let isAdd = !(key in target);
			console.log(`isAdd: ${isAdd}`);
			let res = Reflect.set(target, key, value);
			return res;
		},
		has(target, key) {
			debugger;
			console.log(`obj.has(${toString(key)})`);
			let res = (key in target);
			return res;
		},
		ownKeys(target) {
			debugger;
			// 攔截 loop
			debugger;
			console.log('obj.ownKeys()');
			let keys = Reflect.ownKeys(target);
			return keys
		},
		deleteProperty(target, key) {
			debugger;

			console.log(`obj.delete(${toString(key)})`);
			let res = Reflect.deleteProperty(target, key);
			return res;
		}
	};
}
//----------------------------
// 初級過濾
function _isEmit(method, ob, key){

}
//----------------------------

export function handle(mb) {
	$MB = mb;
	return $objProxySetting;
}
