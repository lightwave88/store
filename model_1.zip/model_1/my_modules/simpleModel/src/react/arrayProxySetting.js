let $MB;

const toString = function(value){
	try {
		value = value.toString();
	} catch (e){
		value = ('' + value);
	}
	return value;
}
//------------------
function arrayProxySetting($this) {

	const $tools = $MB.get('tools');
	const $makeProxy = $MB.get('makeProxy');

	return {
		get(target, key) {
			// GET
			debugger;
			let keyName =
			console.log(`array.get(${toString(key)})`);
			if ($tools.isGetRawdata(key)) {
				return target;
			}
			let value = target[key];
			return value;
		},
		set(target, key, value) {
			debugger;

			console.log(`array.set(${toString(key)})`);

			if (!$tools.hasObserve(value)) {
				let data = $makeProxy(value, $this);
				value = data.proxy;
			}
			target[key] = value;
			return true;
		},
		has(target, key) {
			// GET
			debugger;
			console.log(`array.has(${toString(key)})`);
			let res = Reflect.has(target, key);
			return res;
		},
		ownKeys(target) {
			// GET
			debugger;
			console.log('array.ownKeys()');
			let res = Reflect.ownKeys(t);
			return res;
		},
		deleteProperty(target, key) {
			debugger;
			console.log(`array.delete(${toString(key)})`);
			let res = Reflect.deleteProperty(target, key);
			return res;
		},
	};
}


export function handle(mb) {
	$MB = mb;
	return arrayProxySetting;
}
