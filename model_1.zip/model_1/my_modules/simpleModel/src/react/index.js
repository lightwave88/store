import MB from '../mb.js';
const $MB = new MB();
//-------------
import {
	handle as h_makeProxy
} from './makeProxy.js';
$MB.importHandle('makeProxy', h_makeProxy);
//-------------
import {
	handle as h_ob
} from './observe.js';
$MB.importHandle('ObserveNode', h_ob);
//-------------
import {
	handle as h_arrayProto
} from './arrayMethod.js';
$MB.importHandle('getArrayProto', h_arrayProto);
//-------------
import {
	handle as h_arrayProxy
} from './arrayProxySetting.js';
$MB.importHandle('arrayProxySetting', h_arrayProxy);
//-------------
import {
	handle as h_objProxy
} from './objProxySetting.js';
$MB.importHandle('objProxySetting', h_objProxy);
//-------------
$MB.export(function() {
	let makeProxy = this.get('makeProxy');
	return makeProxy;
});

export default $MB;
