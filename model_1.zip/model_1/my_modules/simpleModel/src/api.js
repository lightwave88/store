let $MB;

function $api(data) {
	return $api.create(data);
}


$api.create = function (data) {
	debugger;
	const makeProxy = $MB.get('makeProxy');
	let {
		proxy
	} = makeProxy(data);
	return proxy;
};

export function handle(mb) {
	$MB = mb;
	return $api;
}
