let $MB;

let $uid = 0;

class ObserveNode {
	$id;
	// $model;

	// 原本的數據
	$raw;
	$proxy;
	$parent;
	// 新的屬性,要往下傳播訊息用的
	$childs = new Set();

	// 確定 data 的型別
	$isArray = false;
	//--------
	// 是否有 arrayMethod 執行
	$arrayMethod;
	// 特殊
	$prevLength;
	//-----------------------
	constructor(data) {
		// debugger;
		const $bb = $MB.get('bb');
		const $tools = $MB.get('tools');

		this.$id = 'ob_' + $uid++;
		this.$raw = data;

		$tools.dataLinkOb(data, this);

		let proxySetting;
		if (Array.isArray(data)) {
			this.$isArray = true;
			proxySetting = this._initArrayData(data);
		} else if ($bb.$isPlainObject(data)) {
			proxySetting = this._initObjData(data);
		} else {
			throw new Error('...');
		}
		this.$proxy = new Proxy(data, proxySetting);
	}
	//-----------------------
	get data() {
		return this.$raw;
	}

	get arrayMethod() {
		if (!this.$isArray) {
			throw new Error('...');
		}
		return (this.$arrayMethod || null);
	}

	get prevLength() {
		if (!this.$isArray) {
			throw new Error('...');
		}
		return this.$prevLength;
	}
	//-----------------------
	setParent(ob) {
		// debugger;
		if (!(ob instanceof ObserveNode)) {
			throw new Error('...');
		}
		if (this.$parent != null) {
			// 不可以隸屬多個數據樹
			throw new Error('...');
		}
		this.$parent = ob;
		ob.$childs.add(this);
		// this.$model = ob.$model;
	}
	//-----------------------
	// 與 parent 斷除關係
	delete() {
		if(this.$parent == null){
			return;
		}
		// this.$model = undefined;
		this.$parent.$childs.delete(this);
		this.$parent = undefined;
	}
	//-----------------------
	isEqual(ob) {
		if (!(ob instanceof ObserveNode)) {
			return false;
		}
		return (this.$id == ob.$id);
	}
	//-----------------------
	// API
	// 由 proxy 呼叫
	emit(args = {}) {
		let {
			path,
			type,
			action,
		} = args;
		console.log('emit: ', JSON.stringify(args));

		// this._bubbling(this, args);
	}
	//-----------------------
	_initArrayData(data) {
		// debugger;
		const getArrayProto = $MB.get('getArrayProto');
		const arrayProto = getArrayProto();
		Reflect.setPrototypeOf(data, arrayProto);

		const arrayProxySetting = $MB.get('arrayProxySetting');
		return arrayProxySetting(this);
	}
	//-----------------------
	_initObjData() {
		// debugger;
		const objProxySetting = $MB.get('objProxySetting');
		return objProxySetting(this);
	}
	//-----------------------
	_bubbling(ob, info) {
		
	}
} // class

////////////////////////////////////////
export function handle(mb) {
	$MB = mb;
	return ObserveNode;
}
