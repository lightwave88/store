let $MB;


const $reg_1 = /^(\d+|length)$/;
const $reg_2 = /^\d+$/;
const $reg_length = /^length$/;
//------------------
function arrayProxySetting($this) {

	const $tools = $MB.get('tools');
	const $makeProxy = $MB.get('makeProxy');

	return {
		// get
		get(target, key) {
			debugger;
			console.log(`array.get(${$toString(key)})`);
			if (_isGetRawdata(key)) {
				return target;
			}
			let value = target[key];
			let ob = _getOb(target);
			//-------------
			_emit('get', ob, target, key, [key]);
			return value;
		},
		// set
		set(target, key, value) {
			debugger;

			console.log(`array.set(${$toString(key)})`);

			let ob = _getOb(target);

			const isLengthKey = $reg_length.test(key);
			const isIndexKey = $reg_2.test(key);
			const $hasArrayMethod = (ob.arrayMethod != null);

			let prevValue = target[key];
			let arg = null;

			if (isLengthKey) {
				// 修改 length

				if ($hasArrayMethod) {
					prevValue = ob.prevLength;
					arg = [prevValue, value];
				} else {
					// 直接變動 array.length
					arg = [prevValue, value];
					_setLength(target, ob, arg);
				}

			} else if (isIndexKey) {
				// 修改 index

				// 對新數據添加觀察者
				if (!_hasObserve(value)) {
					let data = $makeProxy(value, $this);
					value = data.proxy;
				}

				// 移除舊數據
				if (!$hasArrayMethod) {
					let prevOb = _getOb(prevValue);
					if (prevOb != null) {
						prevOb.delete();
					}
				}
			}
			//-------------
			// set
			target[key] = value;

			_emit('set', ob, target, key, [key], arg);

			return true;
		},
		// has
		has(target, key) {
			debugger;
			// GET
			debugger;
			console.log(`array.has(${$toString(key)})`);

			let ob = _getOb(target);
			let res = Reflect.has(target, key);
			//-------------
			_emit('has', ob, target, key, [key]);
			return res;
		},
		// ownKeys
		ownKeys(target) {
			// GET
			debugger;
			console.log('array.ownKeys()');

			// let ob = _getOb(target);
			let res = Reflect.ownKeys(target);
			//-------------
			// _emit('ownKeys', ob, target, key, []);
			return res;
		},
		// deleteProperty
		deleteProperty(target, key) {
			debugger;
			console.log(`array.delete(${$toString(key)})`);

			let prevValue = target[key];

			let res = Reflect.deleteProperty(target, key);
			if (!res) {
				return res;
			}
			let ob = _getOb(target);
			let prevOb = _getOb(prevValue);
			if (prevOb != null) {
				prevOb.delete();
			}
			//-------------
			_emit('delete', ob, target, key, [key]);
			return res;
		},
	};
}
//----------------------------
function _emit(type, ob, target, key, path, compareValue = null) {
	debugger;

	// 是否有執行 array.method
	const arrayMethod = ob.arrayMethod;

	console.log(`arrayMethod: ${arrayMethod}`);

	if (Array.isArray(compareValue)) {
		// 若有比較前後數據前後變化的情景
		let [value1, value2] = compareValue;
		if ((value1 - value2) == 0) {
			return;
		}
	}

	if (key != null) {
		let key_type = typeof (key);

		switch (key_type) {
			case 'symbol':
				return;
				break;
			default:
				// 若 key 不是數字, length
				if (!$reg_1.test(key)) {
					return;
				}
				break;
		} // switch

		if (key == 'length') {
			switch (arrayMethod) {
				case 'at':
					return;
					break;
			} // switch
		}
	}
	//-------------
	// emit...
	debugger;
	let action = 'GET';
	let _type;

	switch (type) {
		case 'get':
			if (key == 'length') {
				path = [];
				_type = 'r.length';
			} else {
				_type = 'r';
			}
			break;
		case 'set':
			action = 'SET';
			if (key == 'length') {
				path = [];
				_type = 'r.length';
			} else {
				_type = 'r';
			}
			break;
		case 'has':
		case 'ownKeys':
			_type = 'r';
			break;
		case 'delete':
			action = 'SET';
			_type = 'r';
			break;
	}
	//-------------
	debugger;
	ob.emit({
		method: type,
		path,
		type: _type,
		action
	});
}
//----------------------------
function $toString(value) {
	const $tools = $MB.get('tools');
	return $tools.toString(value);
}
//----------------------------
// 判斷 key 是否是要取得 rawData
function _isGetRawdata(key) {
	const $tools = $MB.get('tools');
	return $tools.isGetRawdata(key);
}
//----------------------------
// 取得 observe
function _getOb(data) {
	const $tools = $MB.get('tools');
	return $tools.getObserve(data);
}

//----------------------------
function _hasObserve(data) {
	const $tools = $MB.get('tools');
	return $tools.hasObserve(data);
}
//----------------------------
// 因應直接修改 [].length
function _setLength(target, ob, arg) {
	debugger;

	if (ob.arrayMethod != null) {
		return;
	}
	const $tools = $MB.get('tools');

	let [prevLength, length] = arg;

	if (length < prevLength) {
		// [].delete
		for (let i = length; i < prevLength; i++) {
			debugger;
			let value = target[i];
			let child_ob = $tools.getObserve(value);
			if (child_ob != null) {
				child_ob.delete();
			}
			_emit('delete', ob, target, i, [i]);
		}
	} else if (length > prevLength) {
		// [].add
		/*
		for (let i = prevLength; i < length; i++) {
			debugger;
			_emit('set', ob, target, i, [i]);
		}
		*/
	}
}
//----------------------------

export function handle(mb) {
	$MB = mb;
	return arrayProxySetting;
}
