let $MB;

function $api(data) {
	return $api.create(data);
}

//-----------------------
$api.create = function(data) {
	debugger;
	const makeProxy = $MB.get('makeProxy');
	let {
		proxy
	} = makeProxy(data);
	return proxy;
};
//-----------------------
$api.getRawData = function(data) {
	const $tools = $MB.get('tools');
	return $tools.getRawData(data);
}

export function handle(mb) {
	$MB = mb;
	return $api;
}
