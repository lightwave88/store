// debugger;
import MB from './mb.js';
const $mb = new MB();
//-------------
import {
	handle as h_config
} from './config.js';
$mb.importHandle('config', h_config);
//-------------
import {
	handle as h_tools
} from './tools.js';
$mb.importHandle('tools', h_tools);
//-------------
import {
	handle as h_reactAPI
} from './reactAPI.js';
$mb.importHandle('reactAPI', h_reactAPI);
//-------------
import {
	handle as h_modelAPI
} from './modelAPI.js';
$mb.importHandle('modelAPI', h_modelAPI);
//-------------
import m_makeProxy from './react/index.js';
$mb.importModule('makeProxy', m_makeProxy);
//-------------
import m_model from './model/index.js';
$mb.importModule(['Model', 'createListener'], m_model);
//-------------
export function handle(bb) {
	$mb.import('bb', bb);
	let reactAPI = $mb.get('reactAPI');
	let modelAPI = $mb.get('modelAPI');

	bb['reactive'] = reactAPI;
	bb['model'] = modelAPI;
}
