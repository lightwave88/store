let $MB;

// modelAPI
const $modelAPI = {
	create(data) {
		// debugger;
		const Model = $MB.get('Model');
		let model = new Model(data);
		return model;
	},
	//------------------
	update(oldData, newData, keyName, noMatchDel = true) {

	}
};

export function handle(mb) {
	$MB = mb;
	return $modelAPI;
}
