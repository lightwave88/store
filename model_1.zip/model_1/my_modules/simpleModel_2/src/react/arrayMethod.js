let $MB;
const $arrayProto = Array.prototype;
let $arrayProtoClone;
//------------------
let arrayAttrs = Object.getOwnPropertyNames($arrayProto);

let $excludedList = [
	'constructor'
]
// 搜索
let $methods_1 = [
	'find',
	'findIndex',
	'findLast',
	'findLastIndex',
	'includes',
	'indexOf',
	'lastIndexOf'
];

// 修改
let $methods_2 = [
	'push',
	'pop',
	'shift',
	'unshift',
	'splice',
];

// 特殊
let $methods_3 = ['at'];

$excludedList = $excludedList.concat($methods_1);
$excludedList = $excludedList.concat($methods_2);
$excludedList = $excludedList.concat($methods_3);
//------------------
function defProperty(obj, attrName, fn) {
	Object.defineProperty(obj, attrName, {
		value: fn,
		writable: false,
		configurable: false,
		enumerable: false,
	});
}
//----------------------------
// API
function getArrayProto() {
	// debugger;
	if ($arrayProtoClone != null) {
		return $arrayProtoClone;
	}
	//----------------------------
	const $tools = $MB.get('tools');

	// init $arrayProtoClone
	$arrayProtoClone = Object.create($arrayProto);
	//----------------------------
	(() => {
		// debugger;
		// 針對 arrya.search
		let list = $methods_1;
		while (list.length > 0) {
			let method = list.pop();
			const $origin = $arrayProto[method];
			//-------------
			defProperty($arrayProtoClone, method, function(...args) {
				debugger;

				console.log(`array.${method}`);
				// console.dir(args);
				let raw = $tools.getRawData(this);
				let ob = $tools.getObserve(this);

				ob.$prevLength = raw.length;
				ob.$arrayMethod = method;
				let res = $origin.apply(this, args);
				debugger;
				ob.$prevLength = undefined;
				ob.$arrayMethod = undefined;
				debugger;
				//-------------
				// 可以讓所有所屬數據都激起依賴信號
				for (let i = 0; i < this.length; i++) {
					this[i];
				}
				//-------------
				return res;
			}); // def
		} // while
	})();
	//----------------------------
	(() => {
		let list = $methods_2;

		// 針對 array 的修改方法
		while (list.length > 0) {
			let method = list.pop();
			const $origin = $arrayProto[method];
			//-------------
			defProperty($arrayProtoClone, method, function(...args) {
				debugger;
				debugger;
				console.log(`array.${method}`);
				// console.dir(args);

				let raw = $tools.getRawData(this);
				let ob = $tools.getObserve(this);
				//-------------
				// 當 proxy.set.length 時
				// 讀取的 prevLength 會不正確
				ob.$prevLength = raw.length;
				ob.$arrayMethod = method;

				let value = $origin.apply(this, args);
				debugger;

				ob.$arrayMethod = undefined;
				ob.$prevLength = undefined;

				debugger;
				switch (method) {
					case 'splice':
					case 'pop':
					case 'shift':
						_deleteOb(value);
						break;
				}
				//-------------
				return value;
			}); // def
		} // while
	})();
	//----------------------------
	(() => {
		// 針對特殊 method
		let list = $methods_3;
		while (list.length > 0) {
			let method = list.pop();
			const $origin = $arrayProto[method];
			//-------------
			defProperty($arrayProtoClone, method, function(...args) {
				debugger;
				console.log(`array.${method}`);
				// console.dir(args);

				let raw = $tools.getRawData(this);
				let ob = $tools.getObserve(this);
				//-------------
				ob.$prevLength = raw.length;
				ob.$arrayMethod = method;
				let res = $origin.apply(this, args);
				ob.$prevLength = undefined;
				ob.$arrayMethod = undefined;
				//-------------
				return res;
			}); // def
		} // while
	})();
	//----------------------------
	// 其他的 array.method
	while (arrayAttrs.length > 0) {
		// debugger;
		let method = arrayAttrs.pop();
		if ($excludedList.includes(method)) {
			continue;
		}
		if (typeof($arrayProto[method]) != 'function') {
			continue;
		}
		const $origin = $arrayProto[method];
		// console.log(method);
		//-------------
		defProperty($arrayProtoClone, method, function(...args) {
			debugger;
			console.log(`array.${method}`);
			// console.dir(args);

			let raw = $tools.getRawData(this);
			let ob = $tools.getObserve(this);
			//-------------
			ob.$prevLength = raw.length;
			ob.$arrayMethod = method;
			let res = $origin.apply(this, args);
			debugger;
			ob.$prevLength = undefined;
			ob.$arrayMethod = undefined;
			//-------------
			return res;
		}); // def
	} // while

	//----------------------------
	return $arrayProtoClone;
}
//------------------
function _deleteOb(list) {
	debugger;
	const $tools = $MB.get('tools');

	if (!Array.isArray(list)) {
		list = [list];
	}

	while (list.length > 0) {
		let value = list.pop();
		let ob = $tools.getObserve(value);
		if (ob != null) {
			ob.remove();
		}
	} // while
}
//------------------
export function handle(mb) {
	$MB = mb;
	return getArrayProto;
}
