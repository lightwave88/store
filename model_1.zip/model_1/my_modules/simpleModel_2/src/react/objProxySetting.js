let $MB;

// API
function $objProxySetting($this) {

	const $makeProxy = $MB.get('makeProxy');
	const $tools = $MB.get('tools');
	//-----------------------
	return {
		// get
		get(target, key) {
			console.log(`obj.get(${$toString(key)})`);

			if (_isGetRawdata(key)) {
				return target;
			}
			if (typeof(key) == 'symbol') {
				return target[key];
			}
			//-------------
			// debugger;
			let value = Reflect.get(target, key);
			let ob = _getOb(target);
			//-------------
			_emit('get', ob, target, key, [key]);

			return value;
		},
		// set
		set(target, key, value) {
			console.log(`obj.set(${$toString(key)})`);
			debugger;

			let prevValue = target[key];

			if (!_hasObserve(value)) {
				let data = $makeProxy(value, $this);
				value = data.proxy;
			}
			//-------------
			let isAdd = !(key in target);

			let res = Reflect.set(target, key, value);
			if (!res) {
				return res;
			}
			//-------------
			// debugger;
			let ob = _getOb(target);
			let prevOb = _getOb(prevValue);

			if (!isAdd && prevOb != null) {
				debugger;
				prevOb.remove();
			}
			//-------------
			_emit('set', ob, target, key, [key]);
			if (isAdd) {
				_emit('set.length', ob, target, key, []);
			}
			return res;
		},
		// has
		has(target, key) {
			console.log(`obj.has(${$toString(key)})`);
			// debugger;

			let ob = _getOb(target);
			let res;
			if (_isGetRawdata(key)) {
				res = true;
			} else {
				res = (key in target);
			}
			//-------------
			_emit('has', ob, target, key, [key]);
			return res;
		},
		// ownKeys
		ownKeys(target) {
			console.log('obj.ownKeys()');
			// debugger;
			// 攔截 {}.loop
			let ob = _getOb(target);
			let keys = Reflect.ownKeys(target);

			_emit('ownKeys', ob, target, null, []);
			return keys
		},
		// delete
		deleteProperty(target, key) {
			console.log(`obj.delete(${$toString(key)})`);
			// debugger;

			let value = Reflect.get(target, key);

			let res = Reflect.deleteProperty(target, key);
			if (!res) {
				return res;
			}
			//-------------
			let ob = _getOb(target);
			let preOb = _getOb(value);
			if (preOb != null) {
				preOb.remove();
			}
			//-------------
			_emit('delete', ob, target, key, [key]);

			_emit('delete.length', ob, target, key, []);
			return res;
		}
	};
}
//----------------------------
// 不激發事件的 key
const $noEmitKeys = [
	'toJSON',
	'toString',
	'valueOf',
];

// 初級過濾
function _emit(type, ob, target, key, path) {
	// debugger;

	if (key != null) {
		let key_type = typeof(key);
		switch (key_type) {
			// key 是 symbol 通常是系統的 attr
			case 'symbol':
				return;
				break;
			default:
				if ($noEmitKeys.includes(key)) {
					// 其他要被忽視的 key
					return;
				}
				break;
		}
	}
	//-------------
	// 資訊整理
	let action;
	let judgeType;
	switch (type) {
		case 'get':
			action = 'GET';
			judgeType = 'r';
			break;
		case 'set':
			action = 'SET';
			judgeType = 'r';
			break;
		case 'set.length':
			action = 'SET';
			judgeType = 'r.length';
			break;
		case 'has':
			action = 'GET';
			judgeType = 'r';
			break;
		case 'ownKeys':
			action = 'GET';
			judgeType = 'r.length';
			break;
		case 'delete':
			action = 'SET';
			judgeType = 'r';
			break;
		case 'delete.length':
			action = 'SET';
			judgeType = 'r.length';
			break;
		default:
			throw new Error('...');
			break;
	}
	//-------------
	ob.emit({
		path,
		type: judgeType,
		action
	});
}
//----------------------------
// for test
function $toString(value) {
	const $tools = $MB.get('tools');
	return $tools.toString(value);
}
//----------------------------
// 判斷 key 是否是要取得 rawData
function _isGetRawdata(key) {
	const $tools = $MB.get('tools');
	return $tools.isGetRawdata(key);
}
//----------------------------
// 取得 observe
function _getOb(data) {
	const $tools = $MB.get('tools');
	return $tools.getObserve(data);
}
//----------------------------
function _hasObserve(data) {
	const $tools = $MB.get('tools');
	return $tools.hasObserve(data);
}

export function handle(mb) {
	$MB = mb;
	return $objProxySetting;
}
