let $MB;

function _linkObserve(data) {
	// debugger;
	const $tools = $MB.get('tools');
	const $bb = $MB.get('bb');

	if (typeof (data) == 'object') {
		if (!(Array.isArray(data) || $bb.$isPlainObject(data))) {
			// 物件只能是兩種格式
			throw new Error('...');
		}
		if ($tools.hasObserve(data)) {
			let ob = $tools.getObserve(data);
			return ob;
		}
	} else {
		// 簡單數值
		return data;
	}
	//------------
	const ObserveNode = $MB.get('ObserveNode');
	let ob = new ObserveNode(data);
	return ob;
}
//-------------------------------------------
function _walkArray(data, p_ob) {
	// debugger;

	for (let i = 0; i < data.length; i++) {
		let value = data[i];
		let {
			proxy
		} = makeProxy(value, p_ob);
		data[i] = proxy;
	}
}
//-------------------------------------------
function _walkPlainObject(data, p_ob) {
	// debugger;

	for (let key in data) {
		// debugger;
		let value = data[key];
		let {
			proxy
		} = makeProxy(value, p_ob);
		data[key] = proxy;
	}
}
//-------------------------------------------
// API
function makeProxy(data, parent = null) {
	// debugger;

	const $bb = $MB.get('bb');
	const $tools = $MB.get('tools');
	const ObserveNode = $MB.get('ObserveNode');

	if(data == null || typeof(data) != 'object'){
		return {
			proxy: data
		};
	}
	//-------------
	if($tools.hasObserve(data)){
		let ob = $tool.getObserve(data);
		return {
			proxy: ob.$proxy
		};
	}
	//-------------
	let ob = _linkObserve(data);
	if (!(ob instanceof ObserveNode)) {
		// 簡單數據
		return {
			proxy: ob
		};
	}
	// debugger;
	if (parent != null) {
		ob.setParent(parent);
	}
	const rawData = ob.$raw;
	// const p_data = ob.$proxy;
	//-------------
	// debugger;

	if (Array.isArray(rawData)) {
		_walkArray(rawData, ob);
	} else if ($bb.$isPlainObject(rawData)) {
		_walkPlainObject(rawData, ob);
	}
	//-------------
	let proxy = ob.$proxy;
	// debugger;
	return {
		proxy,
		ob
	};
}
//-------------------------------------------
export function handle(mb) {
	$MB = mb;
	return makeProxy;
};
