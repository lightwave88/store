let $MB;

let $uid = 0;

class ObserveNode {
	$id;

	// 原本的數據
	$raw;
	// proxy
	$proxy;
	$parent;
	// 新的屬性,要往下傳播訊息用的
	$childs = new Set();

	// 確定 data 的型別
	$isArray = false;
	//--------
	// 是否有 arrayMethod 執行
	$arrayMethod;
	// 特殊
	$prevLength;
	//--------
	$models = new Set();
	//--------
	// 只有 root 才有
	// set()
	$root_changePathes;

	// set()
	$root_activeListeners;

	$root_isCommit = false;
	//-----------------------
	constructor(data) {
		// debugger;
		const $bb = $MB.get('bb');
		const $tools = $MB.get('tools');

		this.$id = 'ob_' + $uid++;
		this.$raw = data;

		$tools.dataLinkOb(data, this);

		let proxySetting;
		if (Array.isArray(data)) {
			this.$isArray = true;
			proxySetting = this._initArrayData(data);
		} else if ($bb.$isPlainObject(data)) {
			proxySetting = this._initObjData(data);
		} else {
			throw new Error('...');
		}
		this.$proxy = new Proxy(data, proxySetting);
	}
	//-----------------------
	get rawData() {
		return this.$raw;
	}

	get data() {
		return this.$proxy;
	}

	// [] 是否使用了方法
	get arrayMethod() {
		if (!this.$isArray) {
			throw new Error('...');
		}
		return (this.$arrayMethod || null);
	}
	// set [].length 會用到
	get prevLength() {
		if (!this.$isArray) {
			throw new Error('...');
		}
		return this.$prevLength;
	}

	get root() {
		let ob = this;
		let root;
		while (ob != null) {
			root = ob;
			ob = ob.$parent;
		}
		return root;
	}
	//-----------------------
	setParent(ob) {
		// debugger;
		if (!(ob instanceof ObserveNode)) {
			throw new Error('...');
		}
		if (this.$parent != null) {
			// 不可以隸屬多個數據樹
			throw new Error('...');
		}
		this.$parent = ob;
		ob.$childs.add(this);
		// this.$model = ob.$model;
	}
	//-----------------------
	// 與 parent 斷除關係
	remove() {
		debugger;
		if (this.$parent == null) {
			return;
		}
		//-------------
		for (let child of this.$childs) {
			child.remove();
		}
		//-------------
		this.$childs.clear();
		this.$childs = null;

		const parent = this.$parent;
		parent.$childs.delete(this);
		this.$parent = undefined;

		for (let model of this.$models) {
			debugger;
			model.remove();
		}
		this.$models.clear();
		this.$models = undefined;
	}
	//-----------------------
	isEqual(ob) {
		if (!(ob instanceof ObserveNode)) {
			return false;
		}
		return (this.$id == ob.$id);
	}
	//-----------------------
	// API
	// 由 proxy 呼叫
	emit(args = {}) {
		let {
			path,
			type,
			action,
		} = args;

		this._bubbling(this, args);
	}
	//-----------------------
	commit() {
		debugger;
		if (this.$parent != null) {
			const root = this.root;
			root.commit();
			return;
		}
		//-------------
		// root
		if (this.$root_isCommit) {
			// 已經提交 commit
			return;
		}
		this.$root_isCommit = true;

		{
			let changes = Array.from(this.$root_changePathes);
			changes = JSON.stringify(changes);
			console.log(`commit >> ${changes}`);
		}

		this._commit(this.$root_changePathes);

		debugger;

		this.$root_changePathes.clear();
		this.$root_changePathes = undefined;
		this.$root_isCommit = false;
	}
	//-----------------------
	addModel(model) {
		this.$models.add(model);
	}
	//-----------------------
	// root
	// 會往 rootOb 傳送
	addActiveListener(obj) {
		let root = this.root;
		if (root.$root_activeListeners == null) {
			root.$root_activeListeners = [];
		}
		root.$root_activeListeners.push(obj);
	}

	// root
	// 會往 rootOb 傳送
	removeActiveListener() {
		const root = this.root;
		if (!Array.isArray(root.$root_activeListeners)) {
			return;
		}
		root.$root_activeListeners.pop();
		if (root.$root_activeListeners.length == 0) {
			root.$root_activeListeners = undefined;
		}
	}

	// root
	curretActiveListener() {
		const root = this.root;
		return root._curretActiveListener()
	}

	_curretActiveListener() {
		if (!Array.isArray(this.$root_activeListeners)) {
			return null
		}
		let index = this.$root_activeListeners.length - 1;
		return (this.$root_activeListeners[index] || null);
	}

	//-----------------------
	_initArrayData(data) {
		// debugger;
		const getArrayProto = $MB.get('getArrayProto');
		const arrayProto = getArrayProto();
		Reflect.setPrototypeOf(data, arrayProto);

		const arrayProxySetting = $MB.get('arrayProxySetting');
		return arrayProxySetting(this);
	}
	//-----------------------
	_initObjData() {
		// debugger;
		const objProxySetting = $MB.get('objProxySetting');
		return objProxySetting(this);
	}
	//-----------------------
	// bottomUp 的行程
	_bubbling(ob, info) {
		// debugger;

		let p_ob = ob.$parent;
		if (p_ob == null) {
			// 到頂了
			// debugger;

			// 記錄有哪些 path 改變
			ob._recordMsg(info);
			// end
			return;
		}
		//------------------
		let {
			path: pathList
		} = info;

		let find = false;
		let data = p_ob.rawData;
		if (Array.isArray(data)) {
			for (let i = 0; i < data.length; i++) {
				// debugger;
				let value = data[i];
				let _ob = getObserve(value);
				if (_ob.isEqual(ob)) {
					find = true;
					pathList.push(i + '');
					break;
				}
			}

		} else if ($bb.$isPlainObject(data)) {
			for (let key in data) {
				// debugger;
				let value = data[key];
				let _ob = getObserve(value);
				if (_ob != null && _ob.isEqual(ob)) {
					find = true;
					pathList.push(key);
					break;
				}
			}
		} else {
			throw new Error('...');
		}

		if (!find) {
			throw new Error('_bubbling error');
		}
		//------------------
		this._bubbling(p_ob, info);
	}
	//-----------------------
	// 處理來自 proxy 傳來的訊息
	_recordMsg(info) {
		// debugger;

		if (this.$parent != null) {
			throw new Error('...');
		}

		let {
			path,
			type,
			action,
		} = info;

		path.push('/');
		if (path.length > 1) {
			path = path.reverse();
		}
		//-------------
		let $key = type + '|' + path.join('.');

		console.log(`${action} >> ${$key}`);

		if (action == 'GET') {
			// debugger;
			// GET
			// 通知現在監聽的 listener
			let listener = this._curretActiveListener();
			if (listener != null) {
				debugger;
				listener.addWatch($key);
			}
		} else {
			debugger;
			// SET
			// 記錄變化的 path
			if (this.$root_changePathes == null) {
				this.$root_changePathes = new Set();
			}
			this.$root_changePathes.add($key);
		}
	}
	//-----------------------
	// top down 的過程
	_commit(pathList) {
		debugger;

		// child observe
		for (let ob of this.$childs) {
			ob._commit(pathList);
		}
		//-------------
		debugger;

		// 監聽自己的 model
		for (let model of this.$models) {
			// model 呼叫 listener
			debugger;
			model.$$$dataChanged(pathList);
		}
	}
	//-----------------------

} // class

////////////////////////////////////////

function getObserve(data) {
	const $tools = $MB.get('tools');
	return $tools.getObserve(data);
}
//-----------------------

export function handle(mb) {
	$MB = mb;
	return ObserveNode;
}
