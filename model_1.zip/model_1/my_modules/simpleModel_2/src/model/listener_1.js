let $MB;
// 判斷類型
const $reg_1 = /^r\.length\|/;
const $reg_2 = /^r\.length$/;

let $UID = 0;

class Lisener {
	$id;
	$context;

	// 隸屬的 model
	$model;
	//-------------
	$fn_update;
	$fn_remove;
	//-------------
	// storeID.type|...path
	$dependPaths = new Set();

	// 是否會受到底層數據變動影響
	// view是不接受
	$isView = false;

	// this.$fn_update 是否經過第一次執行
	$isInited = false;
	//------------------------------------------------
	constructor(model, args = {}) {
		// debugger;
		this.$id = 'listener_' + $UID++;
		this.$model = model;

		let {
			context,
			dataUpdate,
			dataRemove,
		} = args;

		if (context != null) {
			this.$context = context;
		}
		if (isView(context)) {
			this.$isView = true;
		}
		if (typeof(dataUpdate) != 'function') {
			throw new TypeError('...');
		}
		this.$fn_update = dataUpdate;

		if (typeof(dataRemove) == 'function') {
			this.$fn_remove = dataRemove;
		}
	}
	//------------------------------------------------
	get isInited() {
		return this.$isInited;
	}
	//------------------------------------------------
	// (系統)會通知與那些 datapath 相依
	addWatch(input_path) {
		debugger;

		if ($reg_1.test(input_path)) {
			// read.length
			this.$dependPaths.add(input_path);
			return;
		}
		//-------------
		let isFind = this._isMatch_1(input_path);
		if (!isFind) {
			this.$dependPaths.add(input_path);
		}
	}
	//------------------------------------------------
	// 當 store 有變動，會呼叫是否有牽連
	isMatch(pathList) {

		if (!this.$isInited) {
			// 還沒進行數據依賴的偵測
			return true;
		}

		let res = false;
		find: {
			for (let input_path of pathList) {
				// debugger;

				if (this.$dependPaths.has(input_path)) {
					// input = r.length
					res = true;
					break find;
				}
				//-------------
				for (let path of this.$dependPaths) {
					// debugger
					if (this._isMatch(input_path, path)) {
						res = true;
						break find;
					}
				} // loop

			} // loop
		}
		return res;
	}
	//------------------------------------------------
	// callback
	dataChanged(options = {}) {
		debugger;

		// listener
		// listener
		// listener

		if (!this.$isInited) {
			this.$isInited = true;
		}

		// 重要的地方
		this._clearWatch();
		//-------------
		// let _event = this._getEvent(options);
		const observe = this.$model.observe;
		observe.addActiveListener(this);

		debugger;
		this.$fn_update.call(this.$context, this.$model);

		{
			console.log(`-----listener(${this.$id}).dataChanged()-----`)
			let test = JSON.stringify(Array.from(this.$dependPaths));
			console.dir(test);
			console.log('----------');
		}

		observe.removeActiveListener();
	}
	//------------------------------------------------
	// API
	// 當依存的數據不在了
	remove() {
		debugger;

		if (this.$model == null) {
			// 已經被移除
			return;
		}
		//-------------
		if (this.$fn_remove != null) {
			this.$fn_remove.call(this.$context);
		}
		//-------------
		const model = this.$model;
		this.$model = undefined;

		this.$dependPaths.clear();
		this.$dependPaths = undefined;
	}
	//------------------------------------------------
	_clearWatch() {
		// debugger;
		this.$dependPaths.clear();
	}
	//------------------------------------------------
	_isMatch(input_path, old_path) {
		// debugger;

		let [i_type, i_path] = input_path.split('|');
		let [o_type, o_path] = old_path.split('|');

		if ($reg_2.test(o_type) && i_type != o_type) {
			// o_type = 'r.length'
			return false;
		}
		//-------------
		let input_paths = i_path.split('.');
		let old_paths = o_path.split('.');

		let input_length = input_paths.length
		let old_length = old_paths.length;
		//-------------
		if (!this.$isView) {
			// 自己底層數據變動與自己有關
			let $length = Math.min(input_paths.length, old_paths.length);

			for (let i = 0; i < $length; i++) {
				if (input_paths[i] != old_paths[i]) {
					return false;
				}
			}
			return true;
		} else {
			if (input_length > old_length) {
				// 底層的變動若自己沒讀到，則不與自己有關
				// 底層的變動若自己沒讀到，則不與自己有關
				// 底層的變動若自己沒讀到，則不與自己有關
				return false
			}

			for (let i = 0; i < old_length; i++) {
				if (input_paths[i] == null) {
					break;
				}
				if (input_paths[i] != old_paths[i]) {
					return false;
				}
			} // for
			return true;
		}
	}
	//------------------------------------------------
	_isMatch_1(input_path) {
		// 演算法
		// 遇到(a.b, a.b.c)只取最長 a.b.c
		// a.b.c 同樣可以 match (a, a.b, a.b.c)
		// 可以省去記憶空間
		let [i_type, i_path] = input_path.split('|');
		let input_paths = i_path.split('.');

		// 注意此步驟
		// 因爲會更新 this.$dependPaths
		let cloneData = new Set(this.$dependPaths);

		let isFind = false;
		outside: {
			// 檢查既有的記錄，是否有可以更新的
			for (let old_path of cloneData) {
				// debugger;
				if ($reg_1.test(old_path)) {
					// read.length
					continue;
				}
				let [o_type, o_path] = old_path.split('|');
				//------------------
				// input_path, old_path 比對
				let isSameType = true;
				let needUpdate = true;

				let old_paths = o_path.split('.');
				for (let i = 0; i < old_paths.length; i++) {
					// debugger;
					if (i >= input_paths.length) {
						// input_paths 比較短
						needUpdate = false;
						break;
					}
					let in_key = input_paths[i];
					let o_key = old_paths[i];

					if (in_key != o_key) {
						isSameType = false;
						break;
					}
				} // for
				// input_path, old_path 比對完成
				//------------------
				if (!isSameType) {
					continue;
				} else {
					// sametype
					isFind = true;
					if (needUpdate) {
						// 長度長
						this.$dependPaths.delete(old_path);
						this.$dependPaths.add(input_path);
					}
					break outside;
				}
			} // for
		}

		return isFind;
	}
} // class

//---------------------------------
function isView(obj) {
	let res = false;
	try {
		res = obj.isView;
	} catch (e) {}
	return res;
}

export function handle(mb) {
	$MB = mb;
	return Lisener;
}
