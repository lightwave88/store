let $MB;

let $UID = 0;

class Model {
	$id;

	// 所屬的 ob
	$observe;
	$executedList = new Set();
	$listeners = new Set();
	//---------------------------------
	constructor(data = {}) {
		// debugger;
		const $tools = $MB.get('tools');
		const $bb = $MB.get('bb');
		const makeProxy = $MB.get('makeProxy');

		this.$id = 'model_' + $UID++;

		let jug_1 = !Array.isArray(data);
		let jug_2 = !$bb.isPlainObject(data)

		if (jug_1 && jug_2) {
			throw new TypeError('...');
		}

		let ob = $tools.getObserve(data);
		if (ob == null) {
			({
				ob
			} = makeProxy(data));
		}
		this.$observe = ob;

		// 傾聽 observe
		ob.addModel(this);
	}
	//---------------------------------
	get data() {
		return this.$observe.data;
	}

	get observe() {
		return this.$observe;
	}
	//---------------------------------
	// API
	// (funName, context)
	// (fun, context = null)
	// ({})
	// (object)
	effect(options, context = null) {
		// debugger;
		const $bb = $MB.get('bb');

		let $options = {
			dataUpdate: undefined,
			dataRemove: undefined,
		};

		let type = typeof(options);

		switch (type) {
			case 'string':
				$options.dataUpdate = options;
				break;
			case 'function':
				$options.dataUpdate = options;
				break;
			case 'object':
				Object.assign($options, options);
				break;
			default:
				throw new Error('...');
				break;
		}
		//-------------
		let {
			dataUpdate,
			dataRemove,
		} = $options;

		if (dataUpdate != null) {
			if (typeof(dataUpdate) == 'string') {
				dataUpdate = context[dataUpdate];
			}
		}
		if (dataRemove != null) {
			if (typeof(dataRemove) == 'string') {
				dataRemove = context[dataRemove];
			}
		}
		Object.assign($options, {
			dataUpdate,
			dataRemove,
			context,
		});

		const createListener = $MB.get('createListener');
		const listener = createListener(this, $options);

		// 登錄 listener
		this.$listeners.add(listener);
		//------------------
		function immediate() {
			debugger;
			if (listener.isInited) {
				return;
			}
			listener.dataChanged();
			// debugger;
			if (isDataChanged(this)) {
				this.$executedList.add(listener);
				this.commit();
			}
		}
		return immediate.bind(this);
	}
	//---------------------------------
	// API
	commit() {
		debugger;
		this.$observe.commit();
	}
	//---------------------------------
	// callback
	// 當 model 所屬的 observe 被移除
	remove() {
		debugger;
		for (let listener of this.$listeners) {
			listener.remove();
		}
		this.$listeners.clear();
		this.$listeners = undefined;
	}
	//---------------------------------
	// callback
	// observe 呼叫
	$$$dataChanged(pathList) {
		debugger;

		// model
		// model
		// model

		for (let listener of this.$listeners) {
			debugger;
			if (!listener.isMatch(pathList)) {
				continue;
			}
			//--------
			if (this.$executedList.has(listener)) {
				console.log('<< doubleExecute listener >>');
				continue;
			}
			this.$executedList.add(listener);
			listener.dataChanged(pathList);
		} // for
		//-------------
		this.$executedList.clear();
	}
	//---------------------------------
	toJSON() {
		return this.$observe.data;
	}
	//---------------------------------
	// 取得資料卻不會驚動 proxy
	getRawData(data) {
		return Model.getRawData(data);
	}
	// 取得資料卻不會驚動 proxy
	static getRawData(data) {
		const $tools = $MB.get('tools');
		return $tools.getRawData(data);
	}
	//---------------------------------
	// 更新數據，特殊用法
	update(path, newData, keyName, noMatchDel = true){

	}

} // class
//////////////////////////////

function isDataChanged(model) {
	let ob = model.observe;
	let rootOb = ob.root;
	return Array.isArray(rootOb.$root_changePathes);
}

export function handle(mb) {
	$MB = mb;
	return Model;
}
