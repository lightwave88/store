let $MB;

let $global = (() => {

	// 全域變數
	class Global {
		// 當前執行的 model
		// 還有避免套嵌的問題
		$activeModelStock = [];

		// 當前處理中的 listener
		// 還有避免 listenser 套嵌造成的問題
		// key 是 observe
		$activeListenerStock = new WeakMap();

		// commit() 執行過的 listener
		// 避免 listener 重複執行
		// key 是 observe
		$excutedListenners = new WeakMap();
		//-----------------------
		constructor() { }
		//-----------------------
		// 當前執行的 model
		get activeStore() {
			let index = this.$activeModelStock.length - 1;
			let res = this.$activeModelStock[index] || null;
			return res;
		}
		//-----------------------
		// 當前執行的 listener
		activeListener(ob) {

			if (!this.$activeListenerStock.has(ob)) {
				return null;
			}
			let listeners = this.$activeListenerStock.get(ob);
			let index = listeners.length - 1;
			let res = listeners[index] || null;
			return res;
		}
		//-----------------------
		// 當前處理中的 listener
		// 還有避免 listenser 套嵌造成的問題
		addActiveListener(ob, listener) {
			// debugger;
			const Listener = $MB.get('Listener');
			if (!(listener instanceof Listener)) {
				throw new TypeError('...');
			}
			if (!this.$activeListenerStock.has(ob)) {
				this.$activeListenerStock.set(ob, []);
			}
			let listeners = this.$activeListenerStock.get(ob);
			listeners.push(listener);
		}
		//-----------------------
		removeActiveListener(ob) {
			// debugger;
			if (!this.$activeListenerStock.has(ob)) {
				return;
			}
			let listeners = this.$activeListenerStock.get(ob);
			listeners.pop();

			if(listeners.length == 0){
				this.$activeListenerStock.delete(ob);
			}
		}
		//--------------------------------------------------------------------
		addActiveModel(model) {
			const Model = $MB.get('Model');
			if (!(model instanceof Model)) {
				throw new TypeError('...');
			}
			this.$activeModelStock.push(model);
		}
		//-----------------------
		removeActiveModel() {
			this.$activeModelStock.pop();
		}
		//--------------------------------------------------------------------
		// 防止listener重複執行
		addExcutedListener(listener) {
			this.$excutedListenners.add(listener);
		}
		//-----------------------
		// listener 是否執行過
		isExcuted(listener) {
			return this.$excutedListenners.has(listener);
		}
		//-----------------------
		clearExcutedListeners() {
			this.$excutedListenners.clear();
		}
	} // class

	return new Global();
})();

export function handle(mb) {
	$MB = mb;
	return $global;
}
