let $GM;

const $config = {
  'stroeUpdate_callbackName': 'c_dataUpdate',
};

export function handle(gm){
  $GM = gm;
  return $config;
};
