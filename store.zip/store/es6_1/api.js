let $GM;

const store_api =  {

  // create store
  create(data = {}) {
    debugger;
    const SimpleStore = $GM.get('SimpleStore');
    let store = new SimpleStore(data);
    return store;
  }
}

export function handle(gm) {
  $GM = gm;
  return store_api;
}
