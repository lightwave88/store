let $GM;

const $reg_1 = /^([^.]+)(|[.].+)$/;
const $reg_2 = /(?:|\.)([^.]+)$/;

class Keymap {

  $parent_store;
  // 屬於的
  $store;
  $key;
  $relate_path;
  //-------------
  // 會與 store.link() store.unlink() 有關
  $root_store;
  $real_path;
  //--------------------------------------
  constructor(store, options = {}) {
    debugger;

    const $tools = $GM.get('tools');

    let {
      store: parent_store,
      key,
      path
    } = options;

    this.$store = store;
    this.$key = key;

    this.$parent_store = parent_store;
    this.$relate_path = $tools.regulePath(path);

    // this.$root_store;
    // this.$real_path;
    this._updatePath();
  }
  //--------------------------------------
  get store() {
    return this.$store;
  }

  get parentStore() {
    return this.$parent_store;
  }

  get path() {
    return this.$relate_path;
  }

  get realPath() {
    return {
      path: this.$real_path,
      store: this.$root_store,
    }
  }
  //--------------------------------------
  getValue() {
    // debugger;

    const $tools = $GM.get('tools');
    let value = undefined;

    if (this.$real_path == null || this.$root_store == null) {
      return value;
    }
    let path = this.$real_path;
    let data = this.$root_store.getData();

    try {
      value = $tools.getDataByPath(data, path);
    } catch (e) {}

    // debugger;

    return value;
  }
  //--------------------------------------
  // 取得之前的
  getPrevValue() {
    const $tools = $GM.get('tools');
    let value = undefined;

    if (this.$real_path == null || this.$root_store == null) {
      return value;
    }
    let path = this.$real_path;
    let data = this.$root_store.getPrevData();

    try {
      value = $tools.getDataByPath(data, path);
    } catch (e) {}

    // debugger;

    return value;
  }
  //--------------------------------------
  setValue(value) {
    debugger;

    let {
      key,
      data
    } = this.getUpLevelData();

    debugger;

    if (data == null || typeof(data) != 'object') {
      return;
    }
    //------------------
    const $bb = $GM.get('bb');
    let _class = $bb.getClass(data);
    switch (_class) {
      case 'Object':
        data[key] = value;
        break;
      case 'Array':
        key = parseInt(key, 10);
        data[key] = value;
        break;
      case 'Map':
        data.set(key, value);
        break;
      case 'Set':
        throw new TypeError('no support Set');
        break;
      default:
        break;
    } // switch
  }
  //--------------------------------------
  delValue() {
    debugger;
    // 取得上一層的 data
    let {
      key,
      data
    } = this.getUpLevelData();

    debugger;

    if (data == null || typeof(data) != 'object') {
      return false;
    }
    //------------------
    const $bb = $GM.get('bb');
    let res = true;
    let _class = $bb.getClass(data);
    switch (_class) {
      case 'Object':
        res = delete data[key];
        break;
      case 'Array':
        key = parseInt(key, 10);
        if (key >= data.length) {
          res = false;
          break;
        }
        data.splice(key, 1);
        break;
      case 'Map':
        if (data.has(key)) {
          res = false;
          break;
        }
        data.delete(key);
        break;
      default:
        res = false;
        throw new TypeError(`no support type(${_class})`);
        break;
    } // switch
    return res;
  }
  //--------------------------------------
  // 取得上一層的 data
  getUpLevelData() {
    // debugger;

    const $tools = $GM.get('tools');

    let res = undefined;
    let path = this.$real_path;

    let key;
    path = path.replace($reg_2, (match, g1) => {
      key = g1;
      return '';
    });

    if (this.$real_path == null || this.$root_store == null) {
      // 數據已經脫鉤
    } else {
      let data = this.$root_store.getData();
      res = $tools.getDataByPath(data, path);
    }
    return {
      key,
      data: res
    };
  }
  //--------------------------------------
  // 當 store.unlink() 必須更新路徑
  storeUnlink(store, parentKey) {
    debugger;

    // 當 store.unlink() 會呼叫所有的 keymap 做檢查
    // 必須是自己參照的 store 才會繼續
    if (!this.$store.isEqual(store)) {
      return false;
    }

    let reg = RegExp(`^${parentKey}[.]`);
    if (!reg.test(this.$real_path)) {
      return false;
    }

    this._updatePath();
    return true;
  }
  //--------------------------------------
  // 更新與 root_store 的路徑
  _updatePath() {
    debugger;
    let res = this.getRootPath();

    debugger;
    if (res == null) {
      // 脫鉤了
      this.$real_path = null;
      this.$root_store = null;
    } else {

      let {
        store: rootStore,
        path: realpath
      } = res;

      this.$real_path = realpath;
      this.$root_store = rootStore;
    }
  }
  //--------------------------------------
  getRootPath() {
    debugger;
    let pathList = this.path.split('.');
    let store = this.parentStore;

    while (true) {
      debugger;
      let key = pathList[0];

      if (key in store.$data) {

        break;
      } else if (key in store.$keysMap) {

        pathList.shift();
        let keymap = store.$keysMap[key];
        let _path = keymap.path;
        let _pathList = _path.split('.');
        store = keymap.parentStore;
        pathList = _pathList.concat(pathList);
      } else {
        // 沒找到
        store = null;
        pathList.length = 0;
        break;
      }
    } // while

    let res;

    if (store != null) {
      let path = pathList.join('.');
      res = {
        store,
        path,
      }
    }

    return res;
  }
  //--------------------------------------
  // 用來確定 event 與自己是否有關
  // 有關，會返回一個專屬轉譯過的的 event
  test(storeEvent) {
    debugger;

    const $tools = $GM.get('tools');

    let {
      store,
      pathList: e_pathList,
    } = storeEvent;

    if (this.$real_path == null) {
      // 已經與數據樹脫鉤了
      return null;
    }

    if (!store.isEqual(this.$parent_store)) {
      // 不屬於自己的印射
      return null;
    }
    //------------------
    let pathList = this.$real_path.split('.');

    // 路徑比較
    let isSame = true;
    // let i = 0;

    // 路徑比對
    while (true) {
      debugger;
      // let j = i++;

      let my_key = pathList[0];
      let event_key = e_pathList[0];

      if (my_key == null || event_key == null) {
        break;
      }

      if (my_key !== event_key) {
        isSame = false;
        break;
      }

      pathList.shift();
      e_pathList.shift();
    } // while

    if (!isSame) {
      // 路徑不匹配
      return null;
    }
    //------------------
    // 重點，路徑轉接
    // 重點，路徑轉接
    // 重點，路徑轉接

    let e_paths = [];

    if (pathList.length < e_pathList.length) {
      // 發生事件的路徑，在本體之下
      e_paths.push(this.$key);
      e_paths = e_paths.concat(e_pathList);
    } else {
      // 發生事件的路徑，在本體之上
      e_paths.push(this.$key);
    }

    const StoreEvent = $GM.get('StoreEvent');
    let event = new StoreEvent(this.$store, e_paths);
    return event;
  }
}
//------------------------------------------------------------------------------
export function handle(gm) {
  $GM = gm;
  return Keymap;
}
