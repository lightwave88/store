let $GM;

const $tools = {};


//--------------------------------------
{

  $tools.getDataByPath = function(data, path) {
    // debugger;

    const $bb = $GM.get('bb');

    path = $tools.regulePath(path);
    let pathList = path.split('.');

    while (pathList.length > 0) {
      // debugger;

      if (typeof(data) != 'object' || data == null) {
        break;
      }
      let key = pathList.shift();
      let _class = $bb.getClass(data);
      //------------------
      switch (_class) {
        case 'Object':
          data = data[key];
          break;
        case 'Array':
          key = parseInt(key, 10);
          data = data[key];
          break;
        case 'Map':
          data = checkMap(data);
          break;
        case 'Set':
          throw new TypeError('no support Set');
          break;
        default:
          data = undefined;
          break;
      } // switch
      //------------------
    } // while

    return data;
  };
  //-----------------------
  function checkMap(data, key) {
    // debugger;
    while (true) {
      // debugger;
      if (typeof(key) == 'string') {
        if (data.has(key)) {
          data = data.get(key);
          break;
        }
        key = parseInt(key, 10);
        continue;
      }

      if (typeof(key) == 'number') {
        if (data.has(key)) {
          data = data.get(key);
        } else {
          data = undefined;
        }
        break;
      }
    } // while
    return data;
  }
}
//--------------------------------------

{
  // 複製 data 的值
  $tools.copyValue = function(data) {
    const $bb = $GM.get('bb');
    let value = $bb.copyValue(data);
    return value;
  };
}
//--------------------------------------
{
  // 是否需要正規化
  const $reg_1 = /\[.*?\]/;
  const $reg_2 = /\[(.+?)\](?=([^]|$))/g;
  const $reg_3 = /['"]/g;

  // 整理 path 的規格
  $tools.regulePath = function(path) {
    // debugger;

    if (!$reg_1.test(path)) {
      return path;
    }
    $reg_2.index = 0;
    $reg_3.index = 0;
    //-------------
    path = path.replace($reg_2, (...args) => {
      // debugger;
      let [, word, after] = args;

      word = word.replace($reg_3, '');
      let res = `.${word}`;

      switch (after) {
        case '.':
        case '':
        case '[':
          break;
        default:
          res += '.';
          break;
      }
      return res;
    }); // repalce
    //-------------
    return path;
  };
}
//--------------------------------------



export function handle(gm) {
  $GM = gm;
  return $tools;
};
