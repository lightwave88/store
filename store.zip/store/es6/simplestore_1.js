let $GM;

const $reg_1 = /^([^.]+)(|[.].+)$/;
const $reg_2 = /^[.]/;
const $reg_3 = /^(?:([^.]+)($|\.))/;
const $reg_4 = /^(toJSON)$/;

let $UID = 0;

class SimpleStore {
  $id;
  // 傾聽者
  // store => set(...paths)
  $listeners = new Map();
  //------------------
  // 獨立繼承資料結構
  // 隸屬自己的資料
  $data = {};
  $copy_data = {};
  $prev_data = {};
  // proxy
  $dataProxy;

  // 記錄有那些資料變動
  $self_events = [];

  // 有那些 parent_store 變動
  $changeParents = new Set();
  //------------------

  // 對 store 的引用
  // key => Keymap
  $keysMap = {};
  //------------------
  // 與 data 有關聯的物件
  // 當 data 改變會通知
  // key => set(...objs)
  $relatedObjs = new Map();
  //------------------------------------------------
  constructor(data = {}) {
    // debugger;
    const $bb = $GM.get('bb');

    let type = $bb.getClass(data);
    if (type != 'Object') {
      throw new TypeError('data not plainObject');
    }

    const $this = this;
    this.$id = `storeID_${$UID++}`;

    Object.assign(this.$data, data);

    this.$dataProxy = new Proxy(this.$data, {
      set(t, key, value) {
        debugger;
        let res = proxy_setValue.call($this, key, value);
        return res;
      },
      get(t, key) {
        debugger;
        let value = proxy_getValue.call($this, key);
        return value;
      },
      deleteProperty(key) {
        debugger;
        let res = proxy_delValue.call($this, key);
        return res;
      },
      ownKeys(target) {
        debugger;
        let keys = $this.keys();
        return keys;
      },
      has(target, key) {
        debugger;
        let res = $this.hasKey(key);
        return res;
      },
      getOwnPropertyDescriptor(target, key) {
        debugger;
        let value = $this.getData(key);
        return {
          value,
          writable: true,
          enumerable: true,
          configurable: true,
        };
      }
    });
  }
  //------------------------------------------------
  get data() {
    return this.$dataProxy;
  }
  //------------------------------------------------
  // 設置屬於本身的 data
  setData(data) {
    Object.assign(this.$data, data);
  }
  //------------------------------------------------
  // data 的參照
  link(key, parent_store, path) {
    debugger;

    const $tools = $GM.get('tools');
    path = $tools.regulePath(path);
    //------------------
    debugger;
    // parent 的記錄
    const $listeners = parent_store.$listeners;

    if ($listeners.has(this)) {
      // 避免 path 重複
      let set = $listeners.get(this);
      if (set.has(path)) {
        // 重複的 path
        throw new Error(`has link this path(${path})`);
      }
    } else {
      $listeners.set(this, (new Set()));
    }
    //------------------
    if (key in this.$keysMap) {
      // 之前已經有了鏈接，必須先解除
      this.unlink(key);
    }
    //------------------
    debugger;
    const Keymap = $GM.get('Keymap');

    let options = {
      key,
      store: parent_store,
      path
    };

    // 登錄 value 系統
    this.$keysMap[key] = new Keymap(this, options);
    // 登錄事件系統
    let set = $listeners.get(this);
    set.add(path);
  }
  //------------------------------------------------
  unlink(key) {
    debugger;

    if (!(key in this.$keysMap[key])) {
      // 沒有這個參照
      return;
    }

    let o = this.$keysMap[key];
    let {
      path,
      store: parent_store,
    } = o;

    delete this.$keysMap[key];

    {
      if (!parent_store.$listeners.has(this)) {
        return;
      }
      let set = parent_store.$listeners.get(this);
      set.delete(path);

      if (set.size == 0) {
        parent_store.$listeners.delete(this);
      }
    }
    //-------------
    for (let [c_store, paths] of this.$listeners) {
      // 因爲與數據樹斷鏈了
      // 必須通知 child_store 檢查
      c_store.updateKeymap(this, key);
    }
  }
  //------------------------------------------------
  // unlink...
  // 必須往下更新每個 child_store.keysmap
  // 會遞迴往下
  updateKeymap(parent_store, parent_key) {
    debugger;

    if (parent_store == null || parent_key == null) {
      return;
    }

    let keyList;

    if (Array.isArray(key)) {
      keyList = parent_key;
    } else {
      keyList = [parent_key];
    }

    // 記錄自己有那些 key
    // 受上層 store.unlink() 影響
    let keys = [];

    while (keyList.length > 0) {
      debugger;
      let p_key = keyList.pop();

      for (let key in this.$keysMap) {
        debugger;

        let o = this.$keysMap[key];

        // keymap 與上層有關
        let res = o.storeUnlink(parent_store, p_key);
        if (res) {
          keys.push(key);
        }
      }
    }
    //-------------
    debugger;
    for (let [store, paths] of this.$listeners) {
      debugger;
      // 繼續往下
      store.updateKeymap(this, keys);
    }
  }
  //------------------------------------------------
  keys() {
    // debugger;
    let keys_1 = Object.keys(this.$data);
    let keys_2 = Object.keys(this.$keysMap);
    let res = keys_1.concat(keys_2);
    return res;
  }
  //------------------------------------------------
  hasKey(key) {
    if ((key in this.$data) || (key in this.$keysMap)) {
      return true;
    }
    return false;
  }
  //------------------------------------------------
  getData(key = null) {
    let data = undefined;

    if (key != null) {
      debugger;

      data = (() => {
        debugger;

        if (key in this.$data) {
          // 自身的 data
          return this.$data[key];
        }
        if (key in this.$keysMap) {
          // 參照的 data
          let keymap = this.$keysMap[key];
          return keymap.getValue();
        }
        return undefined;
      })();

    } else {

      data = {};
      for (let k in this.$keysMap) {
        // 參照的 data
        let o = this.$keysMap[k];
        data[k] = o.getValue();
      }
      for (let k in this.$data) {
        // 自身的 data
        data[k] = this.$data[k];
      }
    }
    debugger;

    return data;
  }
  //------------------------------------------------
  // override
  // 必須使用者自己實作
  // 預設是認爲數據都已經變動
  c_isDataChange($prevData, $data) {
    return true;
  }
  //------------------------------------------------
  // 提交那些資料變動了
  commit(paths = null) {
    debugger;

    const $tools = $GM.get('tools');
    const $bb = $GM.get('bb');

    if (paths == null) {
      // 若沒指定要發射的路徑
      // 就以自己的所有 key 發射
      paths = Object.keys(this.$data);
      paths = paths.concat(Object.keys(this.$keysMap));
    }

    if (!Array.isArray(paths)) {
      paths = [paths];
    }

    // 先收集
    // store =? set(...paths)
    let emitStores = new Map();

    for (let i = 0; i < paths.length; i++) {
      debugger;

      let path = paths[i];
      path = $tools.regulePath(path);
      // let pathList = path.split('.');

      let key
      let path_1 = path.replace($reg_3, (m, g1) => {
        key = g1;
        return '';
      });
      //-------------
      if (key in this.$data) {
        // 找到來源，是屬於自己的 data
        // 收集(自己數據的變化)
        recordChangeKey(emitStores, this, path);

      } else if (key in this.$keysMap) {
        // 找到來源，是映射的 data

        let keymap = this.$keysMap[key];
        let store = keymap.parentStore();
        let _path = keymap.path();
        _path = _path + '.' + path_1;

        // 收集(參照數據的變化)
        recordChangeKey(emitStores, store, _path);

      } else {
        // 沒有這路徑
        continue;
      }
    } // for
    //------------------
    // 整理發射
    let hasParentData = 0;

    for (let [store, paths] of emitStores) {
      debugger;

      if (this.isEqual(store)) {
        debugger;
        // 自己的變化
        // 更新數據 this.$prev_data
        this.$prev_data = this.$copy_data;
        this.$copy_data = $tools.copyValue(this.$data);

        for (var path of paths) {
          debugger;
          // 準備事件
          let event = makeSelfEvent.call(this, path);
          if (event != null) {
            this.$self_events.push(event);
          }
        }

      } else {
        this.$changeParents.add(store);
        hasParentData++;
        // commet()
        paths = Array.from(paths);
        store.commit(paths);
      }
    }

    // 往往上激發通知，然後等待通告
    // 若沒有往上就 this.$_onChange()
    if (hasParentData == 0) {
      let self_events = this.$self_events;
      this.$self_events = [];
      this.$_onChange(this, self_events);
    }
  }

  //------------------------------------------------
  // 回調，通知那些數據改變
  $_onChange(store, eventList = []) {
    debugger;

    // 本身的事件
    let self_events;

    if (store.isEqual(this)) {
      // 沒有 parent 的通知
      self_events = eventList.slice();
      eventList.length = 0;

    } else {
      // 避免多個 parent_store 造成多次事件發射
      if (this.$changeParents.has(store)) {
        this.$changeParents.delete(store);
      }
      if (this.$changeParents.size > 0) {
        return;
      }
      //------------------
      // events 檢測與轉換

      for (var i = 0; eventList[i] != null; i++) {
        debugger;
        // 來自 parent_store 的事件

        let e = eventList[i];
        //-------------
        for (let key in this.$keysMap) {
          debugger;
          let o = this.$keysMap[key];

          // 確定是屬於那個參照
          let res = o.test(e);
          if (res != null) {
            eventList[i] = res;
            break;
          }
        } // for
        //-------------
        if (!this.isEqual(e.store)) {
          // 有問題未被轉化的 event
          console.dir(e);
          throw new Error('problem event');
        }

      } // for
    }

    eventList = eventList.concat(self_events);
    //-----------------------
    debugger;
    // 通知自己的支持者
    console.log(`notice store(${this.$id})'s listeners`);

    for (let [key, o] of this.$relatedObjs) {
      //
    }
    debugger;
    //-----------------------
    // 往下發射事件
    for (let [listener, paths] of this.$listeners) {
      let event;
      listener.$_onChange(this, eventList);
    }
  }

  //------------------------------------------------
  isEqual(store) {
    if (!(store instanceof SimpleStore)) {
      return false;
    }
    return (this.$id == store.$id);
  }
  //------------------------------------------------
  destory() {

  }
  //------------------------------------------------
  // 增加傾聽者
  addListener(obj = false) {

  }
  //------------------------------------------------
  stopAddListener() {

  }
  //------------------------------------------------

  // 被 parent 提醒
  noticeListener() {
    // do job

    // 通知 listeners
  }
  //------------------------------------------------
  toJSON() {
    return this.getData();
  }

}

export function handle(gm) {
  $GM = gm;
  return SimpleStore;
};
//==============================================================================

function proxy_setValue(key, value) {
  debugger;
  // 若 keymaps 存在，必須先 unlink()
  if (key in this.$keysMap) {
    let o = this.$keysMap[key];
    o.setValue(value);
    return;
  }
  this.$data[key] = value;

  return true;
}
//--------------------------------------
function proxy_getValue(key) {
  debugger;
  const $this = this;
  let value;

  if ($reg_4.test(key)) {
    // toJSON
    return function() {
      let data = $this.getData();
      return data;
    };
  }

  if (key in this.$keysMap) {
    let o = this.$keysMap[key];
    value = o.getValue();
  } else {
    value = this.$data[key];
  }
  return value;
}
//--------------------------------------
function proxy_delValue(key) {
  debugger;
  let res = false;
  if (key in this.$keysMap) {
    // ? 可能有問題的地方
    // ? 可能有問題的地方
    // ? 可能有問題的地方
    let o = this.$keysMap[key];
    res = o.delValue(key);
  } else if (key in this.$data) {
    res =  delete this.$data[key];
  }
  return false;
}
//--------------------------------------
function recordChangeKey(data, store, path) {
  // debugger;
  if (!data.has(store)) {
    data.set(store, (new Set()));
  }
  let set = data.get(store);
  set.add(path);
}
//--------------------------------------
function makeSelfEvent(path) {
  debugger;
  const $tools = $GM.get('tools');

  let $prev_data = this.$prev_data;
  let $data = this.$data;

  $prev_data = $tools.getDataByPath($prev_data, path);
  $data = $tools.getDataByPath($data, path);

  debugger;

  // 數據比對
  if (!this.c_isDataChange($prev_data, $data)) {
    return null;
  }

  const StoreEvent = $GM.get('StoreEvent');
  let event = new StoreEvent(this, path);
  return event;
}
