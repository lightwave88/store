let $GM;

const store_api =  {

  // create store
  create(data = {}, override = {}) {
    debugger;
    const SimpleStore = $GM.get('SimpleStore');
    let store = new SimpleStore(data);

    for (let key in override) {
      let value = override[key];
      store[key] = value;
    }
    return store;
  },
  // 取得可供繼承的 store
  getClass(){
    const SimpleStore = $GM.get('SimpleStore');
    return SimpleStore;
  }
}

export function handle(gm) {
  $GM = gm;
  return store_api;
}
