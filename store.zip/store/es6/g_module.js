let $singleton;

class GModule {
  $parent = null;
  $modules = new Map();
  //--------------------------------------
  constructor(parent = null) {
    if (parent instanceof GModule) {
      this.$parent = parent;
    }
  }

  get parent() {
    return this.$parent;
  }

  set parent(value) {

  }
  //--------------------------------------
  static singleton(){
    if($singleton == null){
      $singleton = new GModule();
    }
    return $singleton;
  }
  //--------------------------------------
  // API
  import(name, module = null) {
    // debugger;

    if (module == null && typeof(name) != 'string') {
      let modules = name;
      name = null;
      Object.keys(modules).forEach((moduleName) => {
        // debugger;
        let m = modules[moduleName];
        this.import(moduleName, m);
      });
      return;
    }

    this.$modules.set(name, module);
  }
  //--------------------------------------
  // API
  // 是否要往上層找
  get(name, justSelf = false) {

    let res = null;

    // 是否要由下往上找
    let buttonUp = !justSelf;

    let $this = this;
    while ($this != null) {
      if ($this.$modules.has(name)) {
        res = $this.$modules.get(name);
        break;
      }
      if (!buttonUp) {
        break;
      }
      $this = $this.$parent;
    }
    return res;
  }
  //--------------------------------------
  // API
  has(name, justSelf = false) {
    let $this = this;

    // 是否要由下往上找
    let buttonUp = !justSelf;

    while ($this != null) {
      if ($this.$modules.has(name)) {
        return true;
      }
      if (!buttonUp) {
        break;
      }
      $this = $this.$parent;
    }
    return false;
  }
  //--------------------------------------
  setParent(p) {
    if (!(p instanceof GModule)) {
      let er = 'gmodule.setParent(parent) must instanceof GModule';
      throw new TypeError(er);
    }
    this.$parent = p;
  }
}
//================================================

export default GModule;
export {GModule};
