let $GM;

// 事件
class StoreEvent {
  $store;
  $pathList;
  //-----------------------
  constructor(store, path = '') {
    this.$store = store;

    if (Array.isArray(path)) {
      this.$pathList = path;
    } else if (typeof(path) == 'string') {
      this.$pathList = path.split('.');
    }
  }
  //-----------------------
  get store() {
    return this.$store;
  }

  get pathList() {
    return this.$pathList.slice();
  }

  get path() {
    return this.$pathList.join('.');
  }
}

export function handle(gm) {
  $GM = gm;
  return StoreEvent
};
