let $GM;

class interface_DataUpdate {
  // 核心物件
  $core;
  $store;
  $keys = null;
  $activeKeys;
  $callbackName;
  //------------------------------------------------
  constructor(store, core) {
    const $config = $GM.get('config');
    this.callbackName = $config['storeUpdate_callbackName'];

    this.$store = store;
    this.$core = core;
    if (typeof core[this.callbackName] != 'function') {
      throw new Error(`need set function: ${this.callbackName}()`);
    }
    
    // callback
    this[this.callbackName] = (prevData, data)=>{
      c_storeUpdate.call(this, prevData, data);
    };
  }
  //------------------------------------------------
  addKey(key) {
    if (this.$keys == null) {
      this.$keys = new Set();
    }

    this.$keys.add(key);
  }
  //------------------------------------------------
  // 當 store 有變動，會呼叫是否有牽連
  test(eventList = []) {
    debugger;

    let res;
    if (this.$keys == null) {
      // 第一次執行
      this.$keys = new Set();
      this.$activeKeys = eventList.map((e) => {
        let events = e.pathList;
        let key = events[0];
        return key;
      });
      res = true;
    } else {

      let keys = eventList.map((e) => {
        debugger;
        let events = e.pathList;
        let key = events[0];
        if (this.$keys.has(key)) {
          return key;
        } else {
          return null;
        }
      });

      this.$activeKeys = keys.filter((key) => {
        return !(key == null);
      });

      if (this.$activeKeys.length > 0) {
        res = true;
      } else {
        this.$activeKeys = null;
        res = false;
      }
    }
    return res;
  }
  //------------------------------------------------
}

// callback
function c_storeUpdate(prevData, data) {
  debugger;
  
  // 記錄 $core 會讀取那些 stroe 的 key
  this.$store.readData(this.$core);
  let keys = this.$activeKeys.slice();
  //-------------
  // 通知變動
  this.$core[this.callbackName](keys, data, prevData);
  //-------------
  debugger;
  this.$activeKeys = null;
  this.$store.readData();
}

export function handle(gm) {
  $GM = gm;
  return interface_DataUpdate;
}
