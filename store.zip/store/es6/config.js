let $GM;

const $config = {
  'storeUpdate_callbackName': 'c_dataUpdate',
};

export function handle(gm){
  $GM = gm;
  return $config;
};
