import {
  GModule
} from './g_module.js';
const $GM = GModule.singleton();

import {
  handle as h_tools
} from './tools.js';
$GM.import('tools', h_tools($GM));

import {
  handle as h_keymap
} from './keymap.js';
$GM.import('Keymap', h_keymap($GM));

import {
  handle as h_storeEvent
} from './storeEvent.js';
$GM.import('StoreEvent', h_storeEvent($GM));

import {
  handle as h_simpleStore
} from './simplestore.js';
$GM.import('SimpleStore', h_simpleStore($GM));

import {
  handle as h_storeAPI
} from './api.js';
$GM.import('store_api', h_storeAPI($GM));

import {
  handle as h_interface_dataupdate
} from './interface_dataupdate.js'
$GM.import('interface_DataUpdate', h_interface_dataupdate($GM));

import {
  handle as h_config
} from './config.js';
$GM.import('config', h_config($GM));
//--------------------------------------
export function handle(bb) {
  $GM.import('bb', bb);
  const store_api = $GM.get('store_api');
  bb.store = store_api;
};
