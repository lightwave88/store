import {
  handle
} from './es6/index.js';

export {
  handle
};
